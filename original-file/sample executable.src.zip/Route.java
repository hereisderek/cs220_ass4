/*    */ public class Route
/*    */ {
/*    */   private int to;
/*    */   private double cost;
/*    */ 
/*    */   public Route(int paramInt, double paramDouble)
/*    */   {
/* 22 */     this.to = paramInt;
/* 23 */     this.cost = paramDouble;
/*    */   }
/*    */ 
/*    */   public int getDestination()
/*    */   {
/* 28 */     return this.to;
/*    */   }
/*    */ 
/*    */   public double getCost() {
/* 32 */     return this.cost;
/*    */   }
/*    */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     Route
 * JD-Core Version:    0.6.2
 */