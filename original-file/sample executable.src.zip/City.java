/*     */ public class City
/*     */ {
/*     */   private String name;
/*     */   private Route[] routes;
/*     */   private Route[] sortedRoutes;
/*     */   private double costTo;
/*     */   private String pathTo;
/*     */   private int lastRouteChecked;
/*     */   private int stepsToSortRoutes;
/*     */   private boolean isInStackOrQueue;
/*     */ 
/*     */   public City(String paramString)
/*     */   {
/*  28 */     this.name = paramString;
/*  29 */     this.costTo = -1.0D;
/*  30 */     this.pathTo = "";
/*  31 */     this.lastRouteChecked = -1;
/*  32 */     this.isInStackOrQueue = false;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  37 */     return this.name;
/*     */   }
/*     */ 
/*     */   public boolean getProcessingStatus()
/*     */   {
/*  42 */     return this.isInStackOrQueue;
/*     */   }
/*     */ 
/*     */   public Route[] getRoutes()
/*     */   {
/*  47 */     return this.routes;
/*     */   }
/*     */ 
/*     */   public Route getRoute(int paramInt) {
/*  51 */     return this.routes[paramInt];
/*     */   }
/*     */ 
/*     */   public Route[] getSortedRoutes()
/*     */   {
/*  56 */     if (this.sortedRoutes == null) {
/*  57 */       sortRoutes();
/*     */     }
/*  59 */     return this.sortedRoutes;
/*     */   }
/*     */ 
/*     */   public double getCostTo() {
/*  63 */     return this.costTo;
/*     */   }
/*     */ 
/*     */   public String getPathTo() {
/*  67 */     return this.pathTo;
/*     */   }
/*     */ 
/*     */   public int getLastRouteChecked() {
/*  71 */     return this.lastRouteChecked;
/*     */   }
/*     */ 
/*     */   public int getStepsToSortRoutes() {
/*  75 */     if (this.sortedRoutes == null) {
/*  76 */       sortRoutes();
/*     */     }
/*  78 */     return this.stepsToSortRoutes;
/*     */   }
/*     */ 
/*     */   public Route[] addRoute(int paramInt, double paramDouble)
/*     */   {
/*  83 */     if (this.routes != null) {
/*  84 */       Route[] arrayOfRoute = new Route[this.routes.length + 1];
/*  85 */       for (int i = 0; i < this.routes.length; i++) {
/*  86 */         arrayOfRoute[i] = this.routes[i];
/*     */       }
/*  88 */       arrayOfRoute[this.routes.length] = new Route(paramInt, paramDouble);
/*  89 */       this.routes = arrayOfRoute;
/*     */     }
/*     */     else
/*     */     {
/*  93 */       this.routes = new Route[1];
/*  94 */       this.routes[0] = new Route(paramInt, paramDouble);
/*     */     }
/*  96 */     return this.routes;
/*     */   }
/*     */ 
/*     */   public void sortRoutes()
/*     */   {
/* 102 */     this.sortedRoutes = new Route[this.routes.length];
/* 103 */     this.stepsToSortRoutes = 0;
/* 104 */     for (int i = 0; i < this.routes.length; i++) {
/* 105 */       this.sortedRoutes[i] = this.routes[i];
/*     */     }
/*     */ 
/* 109 */     for (int j = 1; j < this.sortedRoutes.length; j++)
/* 110 */       for (int k = this.sortedRoutes.length - 1; k >= j; k--) {
/* 111 */         this.stepsToSortRoutes += 1;
/* 112 */         if (this.sortedRoutes[k].getCost() <= this.sortedRoutes[(k - 1)].getCost()) {
/* 113 */           Route localRoute = this.sortedRoutes[k];
/* 114 */           this.sortedRoutes[k] = this.sortedRoutes[(k - 1)];
/* 115 */           this.sortedRoutes[(k - 1)] = localRoute;
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setProcessingStatus(boolean paramBoolean)
/*     */   {
/* 124 */     this.isInStackOrQueue = paramBoolean;
/*     */   }
/*     */ 
/*     */   public void setCostTo(double paramDouble) {
/* 128 */     this.costTo = paramDouble;
/*     */   }
/*     */ 
/*     */   public String setPathToVia(City paramCity, Route paramRoute) {
/* 132 */     this.pathTo = (paramCity.getPathTo() + ", " + paramCity.getName() + " to " + this.name + " ($" + paramRoute.getCost() + ")");
/* 133 */     return this.pathTo;
/*     */   }
/*     */ 
/*     */   public void setLastRouteChecked(int paramInt) {
/* 137 */     this.lastRouteChecked = paramInt;
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 141 */     this.costTo = -1.0D;
/* 142 */     this.pathTo = "";
/* 143 */     this.lastRouteChecked = -1;
/*     */   }
/*     */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     City
 * JD-Core Version:    0.6.2
 */