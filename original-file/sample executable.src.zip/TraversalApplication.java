/*    */ public class TraversalApplication
/*    */ {
/*    */   public static void main(String[] paramArrayOfString)
/*    */   {
/* 16 */     TraversalProgram localTraversalProgram = new TraversalProgram();
/* 17 */     localTraversalProgram.start();
/*    */   }
/*    */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     TraversalApplication
 * JD-Core Version:    0.6.2
 */