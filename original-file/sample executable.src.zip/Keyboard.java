/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Scanner;
/*    */ 
/*    */ public class Keyboard
/*    */ {
/* 18 */   private static Scanner in = new Scanner(System.in);
/* 19 */   private static boolean redirected = false;
/*    */ 
/*    */   public static String readInput()
/*    */   {
/*    */     try {
/* 24 */       if (!redirected)
/* 25 */         redirected = System.in.available() != 0;
/*    */     }
/*    */     catch (IOException localIOException) {
/* 28 */       System.err.println("An error has occurred in the Keyboard constructor.");
/* 29 */       localIOException.printStackTrace();
/* 30 */       System.exit(-1);
/*    */     }
/*    */     try
/*    */     {
/* 34 */       String str = in.nextLine();
/* 35 */       if (redirected) {
/* 36 */         System.out.println(str);
/*    */       }
/* 38 */       return str;
/*    */     } catch (IllegalStateException localIllegalStateException) {
/* 40 */       System.err.println("An error has occurred in the Keyboard.readInput() method.");
/* 41 */       localIllegalStateException.printStackTrace();
/* 42 */       System.exit(-1);
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     Keyboard
 * JD-Core Version:    0.6.2
 */