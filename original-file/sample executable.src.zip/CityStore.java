/*    */ abstract class CityStore
/*    */ {
/*    */   protected City[] cities;
/*    */ 
/*    */   public boolean isEmpty()
/*    */   {
/* 19 */     return (this.cities == null) || (this.cities.length == 0);
/*    */   }
/*    */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     CityStore
 * JD-Core Version:    0.6.2
 */