/*    */ class CityStack extends CityStore
/*    */ {
/*    */   public CityStack()
/*    */   {
/* 17 */     this.cities = new City[0];
/*    */   }
/*    */ 
/*    */   public int push(City paramCity) {
/* 21 */     paramCity.setProcessingStatus(true);
/* 22 */     City[] arrayOfCity = new City[this.cities.length + 1];
/* 23 */     for (int i = 0; i < this.cities.length; i++) {
/* 24 */       arrayOfCity[i] = this.cities[i];
/*    */     }
/* 26 */     arrayOfCity[this.cities.length] = paramCity;
/* 27 */     this.cities = arrayOfCity;
/* 28 */     return this.cities.length;
/*    */   }
/*    */ 
/*    */   public City pop() {
/* 32 */     if (this.cities.length > 0) {
/* 33 */       City localCity = this.cities[(this.cities.length - 1)];
/* 34 */       City[] arrayOfCity = new City[this.cities.length - 1];
/* 35 */       for (int i = 0; i < this.cities.length - 1; i++) {
/* 36 */         arrayOfCity[i] = this.cities[i];
/*    */       }
/* 38 */       this.cities = arrayOfCity;
/* 39 */       localCity.setProcessingStatus(false);
/* 40 */       return localCity;
/*    */     }
/*    */ 
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   public City getStackTop()
/*    */   {
/* 49 */     if (this.cities.length > 0) {
/* 50 */       return this.cities[(this.cities.length - 1)];
/*    */     }
/*    */ 
/* 54 */     return null;
/*    */   }
/*    */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     CityStack
 * JD-Core Version:    0.6.2
 */