/*      */ import java.io.PrintStream;
/*      */ 
/*      */ public class TraversalProgram
/*      */ {
/*      */   private static final int MIN_CITIES = 25;
/*      */   private static final int MAX_CITIES = 51;
/*      */   private City[] cities;
/*      */   private int routeCounter;
/*      */   private int[] whiteCities;
/*      */   private int nextWhiteCity;
/*      */   private int maxCities;
/*      */   private int steps;
/*      */   private int sortSteps;
/*      */ 
/*      */   private int initWhiteCities()
/*      */   {
/*   34 */     int i = 0;
/*   35 */     this.whiteCities = new int[this.maxCities];
/*   36 */     for (int j = 0; j < this.cities.length; j++) {
/*   37 */       this.whiteCities[j] = j;
/*   38 */       i += this.cities[j].getStepsToSortRoutes();
/*      */     }
/*   40 */     this.nextWhiteCity = 0;
/*   41 */     return i;
/*      */   }
/*      */ 
/*      */   private int getNextWhiteCity() {
/*   45 */     while ((this.nextWhiteCity < this.whiteCities.length) && (this.whiteCities[this.nextWhiteCity] < 0)) {
/*   46 */       this.nextWhiteCity += 1;
/*      */     }
/*   48 */     if (this.nextWhiteCity < this.whiteCities.length) {
/*   49 */       return this.nextWhiteCity;
/*      */     }
/*      */ 
/*   53 */     return -1;
/*      */   }
/*      */ 
/*      */   public void doDFS(boolean paramBoolean1, boolean paramBoolean2)
/*      */   {
/*   59 */     Route localRoute = null;
/*   60 */     if (paramBoolean2) {
/*   61 */       this.sortSteps = initWhiteCities();
/*   62 */       this.steps = this.sortSteps;
/*      */     }
/*      */     else
/*      */     {
/*   66 */       initWhiteCities();
/*      */     }
/*      */ 
/*   69 */     CityStack localCityStack = new CityStack();
/*      */     int i;
/*   71 */     while ((i = getNextWhiteCity()) > -1) {
/*   72 */       City localCity1 = this.cities[i];
/*   73 */       localCityStack.push(localCity1);
/*   74 */       this.whiteCities[i] = -1;
/*   75 */       localCity1.setCostTo(0.0D);
/*   76 */       while (!localCityStack.isEmpty()) {
/*   77 */         localCity1 = localCityStack.getStackTop();
/*   78 */         int j = 0;
/*      */ 
/*   80 */         for (int k = localCity1.getLastRouteChecked() + 1; k < localCity1.getRoutes().length; k++) {
/*   81 */           if (paramBoolean2) {
/*   82 */             localRoute = localCity1.getSortedRoutes()[k];
/*      */           }
/*      */           else
/*      */           {
/*   86 */             localRoute = localCity1.getRoutes()[k];
/*      */           }
/*   88 */           localCity1.setLastRouteChecked(k);
/*   89 */           this.steps += 1;
/*   90 */           if (this.cities[localRoute.getDestination()].getCostTo() < 0.0D) {
/*   91 */             j = 1;
/*   92 */             break;
/*      */           }
/*   94 */           if (paramBoolean1)
/*      */           {
/*   97 */             if (this.cities[localRoute.getDestination()].getCostTo() > localCity1.getCostTo() + localRoute.getCost()) {
/*   98 */               j = 1;
/*   99 */               this.cities[localRoute.getDestination()].setLastRouteChecked(-1);
/*  100 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  104 */         if (j != 0) {
/*  105 */           City localCity2 = this.cities[localRoute.getDestination()];
/*  106 */           localCity2.setLastRouteChecked(-1);
/*  107 */           localCityStack.push(localCity2);
/*  108 */           this.whiteCities[localRoute.getDestination()] = -1;
/*  109 */           localCity2.setCostTo(localCity1.getCostTo() + localRoute.getCost());
/*  110 */           localCity2.setPathToVia(localCity1, localRoute);
/*      */         }
/*      */         else
/*      */         {
/*  114 */           localCityStack.pop();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doBFS(boolean paramBoolean1, boolean paramBoolean2)
/*      */   {
/*  122 */     if (paramBoolean2) {
/*  123 */       this.sortSteps = initWhiteCities();
/*  124 */       this.steps = this.sortSteps;
/*      */     }
/*      */     else
/*      */     {
/*  128 */       initWhiteCities();
/*      */     }
/*      */ 
/*  131 */     CityQueue localCityQueue = new CityQueue();
/*      */     int i;
/*  133 */     while ((i = getNextWhiteCity()) > -1) {
/*  134 */       City localCity1 = this.cities[i];
/*  135 */       localCityQueue.enqueue(localCity1);
/*  136 */       this.whiteCities[i] = -1;
/*  137 */       localCity1.setCostTo(0.0D);
/*  138 */       while (!localCityQueue.isEmpty()) {
/*  139 */         localCity1 = localCityQueue.dequeue();
/*      */ 
/*  142 */         for (int j = 0; j < localCity1.getRoutes().length; j++)
/*      */         {
/*      */           Route localRoute;
/*  143 */           if (paramBoolean2) {
/*  144 */             localRoute = localCity1.getSortedRoutes()[j];
/*      */           }
/*      */           else
/*      */           {
/*  148 */             localRoute = localCity1.getRoutes()[j];
/*      */           }
/*  150 */           this.steps += 1;
/*      */           City localCity2;
/*  151 */           if (this.cities[localRoute.getDestination()].getCostTo() < 0.0D) {
/*  152 */             localCity2 = this.cities[localRoute.getDestination()];
/*  153 */             localCityQueue.enqueue(localCity2);
/*  154 */             this.whiteCities[localRoute.getDestination()] = -1;
/*  155 */             localCity2.setCostTo(localCity1.getCostTo() + localRoute.getCost());
/*  156 */             localCity2.setPathToVia(localCity1, localRoute);
/*      */           }
/*  161 */           else if (paramBoolean1)
/*      */           {
/*  163 */             if (this.cities[localRoute.getDestination()].getCostTo() > localCity1.getCostTo() + localRoute.getCost()) {
/*  164 */               localCity2 = this.cities[localRoute.getDestination()];
/*  165 */               if (!localCity2.getProcessingStatus())
/*      */               {
/*  170 */                 localCityQueue.enqueue(localCity2);
/*      */               }
/*      */ 
/*  174 */               localCity2.setCostTo(localCity1.getCostTo() + localRoute.getCost());
/*  175 */               localCity2.setPathToVia(localCity1, localRoute);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void doDijkstra()
/*      */   {
/*  186 */     City[] arrayOfCity = new City[this.cities.length];
/*      */ 
/*  189 */     for (int i = 0; i < this.cities.length; i++) {
/*  190 */       arrayOfCity[i] = this.cities[i];
/*      */     }
/*      */ 
/*  194 */     City localCity1 = this.cities[0];
/*  195 */     this.cities[0].setCostTo(0.0D);
/*  196 */     arrayOfCity[0] = null;
/*      */ 
/*  198 */     i = 1;
/*  199 */     while (i != 0)
/*      */     {
/*  201 */       Route[] arrayOfRoute = localCity1.getRoutes();
/*  202 */       for (int j = 0; j < arrayOfRoute.length; j++) {
/*  203 */         this.steps += 1;
/*  204 */         Route localRoute = arrayOfRoute[j];
/*  205 */         City localCity2 = this.cities[localRoute.getDestination()];
/*      */ 
/*  207 */         if ((localCity2.getCostTo() < 0.0D) || (localCity2.getCostTo() > localCity1.getCostTo() + localRoute.getCost()))
/*      */         {
/*  209 */           localCity2.setCostTo(localCity1.getCostTo() + localRoute.getCost());
/*  210 */           localCity2.setPathToVia(localCity1, localRoute);
/*      */         }
/*      */       }
/*      */ 
/*  214 */       i = 0;
/*  215 */       double d = 1.7976931348623157E+308D;
/*  216 */       int k = 0;
/*  217 */       for (int m = 0; m < arrayOfCity.length; m++) {
/*  218 */         this.steps += 1;
/*  219 */         if ((arrayOfCity[m] != null) && 
/*  220 */           (arrayOfCity[m].getCostTo() > 0.0D) && (arrayOfCity[m].getCostTo() < d)) {
/*  221 */           i = 1;
/*  222 */           localCity1 = arrayOfCity[m];
/*  223 */           k = m;
/*  224 */           d = localCity1.getCostTo();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  229 */       if (i != 0)
/*  230 */         arrayOfCity[k] = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void printCitiesAndPaths()
/*      */   {
/*  240 */     for (int i = 0; i < this.cities.length; i++) {
/*  241 */       City localCity = this.cities[i];
/*  242 */       System.out.print("City: " + localCity.getName());
/*  243 */       if (localCity.getPathTo() == "") {
/*  244 */         System.out.println();
/*  245 */         Route[] arrayOfRoute = localCity.getSortedRoutes();
/*  246 */         for (int j = 0; j < arrayOfRoute.length; j++) {
/*  247 */           Route localRoute = arrayOfRoute[j];
/*  248 */           System.out.println("    Route to: " + this.cities[localRoute.getDestination()].getName() + " for $" + localRoute.getCost());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  253 */         System.out.println(" ($" + localCity.getCostTo() + ")" + localCity.getPathTo());
/*      */       }
/*  255 */       System.out.println();
/*      */     }
/*  257 */     System.out.println(this.cities.length + " cities and " + this.routeCounter + " routes loaded.");
/*  258 */     System.out.println();
/*      */   }
/*      */ 
/*      */   public void start()
/*      */   {
/*  263 */     this.maxCities = -1;
/*  264 */     int i = -1;
/*  265 */     while (i != 0) {
/*  266 */       this.maxCities = -1;
/*  267 */       i = -1;
/*      */ 
/*  269 */       while ((this.maxCities < 25) || (this.maxCities > 51)) {
/*  270 */         System.out.print("Number of cities to initialize (25 to 51) [51]: ");
/*  271 */         String str = Keyboard.readInput();
/*  272 */         if (str.length() == 0) {
/*  273 */           this.maxCities = 51;
/*      */         }
/*      */         else
/*      */         {
/*  277 */           this.maxCities = Integer.parseInt(str);
/*      */         }
/*  279 */         System.out.println();
/*      */       }
/*  281 */       this.sortSteps = 0;
/*  282 */       this.steps = 0;
/*  283 */       initialiseCities();
/*  284 */       printCitiesAndPaths();
/*  285 */       System.out.println();
/*  286 */       System.out.println("1) Perform plain DFS");
/*  287 */       System.out.println("2) Perform DFS with cheapest edge first");
/*  288 */       System.out.println("3) Perform DFS with path optimisation");
/*  289 */       System.out.println("4) Perform DFS with path optimisation and cheapest edge first");
/*  290 */       System.out.println("5) Perform plain BFS");
/*  291 */       System.out.println("6) Perform BFS with cheapest edge first");
/*  292 */       System.out.println("7) Perform BFS with path optimisation");
/*  293 */       System.out.println("8) Perform BFS with path optimisation and cheapest edge first");
/*  294 */       System.out.println("9) Perform the Dijkstra algorithm");
/*  295 */       System.out.println("0) Quit");
/*  296 */       System.out.print("Your choice: ");
/*  297 */       i = Integer.parseInt(Keyboard.readInput());
/*  298 */       System.out.println();
/*  299 */       System.out.println();
/*  300 */       switch (i) {
/*      */       case 1:
/*  302 */         System.out.println("*** Plain DFS ***");
/*  303 */         doDFS(false, false);
/*  304 */         break;
/*      */       case 2:
/*  306 */         System.out.println("*** DFS with cheapest edge first ***");
/*  307 */         doDFS(false, true);
/*  308 */         break;
/*      */       case 3:
/*  310 */         System.out.println("*** DFS with path optimisation ***");
/*  311 */         doDFS(true, false);
/*  312 */         break;
/*      */       case 4:
/*  314 */         System.out.println("*** DFS with path optimisation and cheapest edge first ***");
/*  315 */         doDFS(true, true);
/*  316 */         break;
/*      */       case 5:
/*  318 */         System.out.println("*** Plain BFS ***");
/*  319 */         doBFS(false, false);
/*  320 */         break;
/*      */       case 6:
/*  322 */         System.out.println("*** BFS with cheapest edge first ***");
/*  323 */         doBFS(false, true);
/*  324 */         break;
/*      */       case 7:
/*  326 */         System.out.println("*** BFS with path optimisation ***");
/*  327 */         doBFS(true, false);
/*  328 */         break;
/*      */       case 8:
/*  330 */         System.out.println("*** BFS with path optimisation and cheapest edge first ***");
/*  331 */         doBFS(true, true);
/*  332 */         break;
/*      */       case 9:
/*  334 */         System.out.println("*** Dijkstra ***");
/*  335 */         doDijkstra();
/*  336 */         break;
/*      */       case 0:
/*  337 */         return;
/*      */       }
/*  339 */       printCitiesAndPaths();
/*  340 */       System.out.println("Sorting steps taken (if any): " + this.sortSteps);
/*  341 */       System.out.println("Total steps taken: " + this.steps);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void initialiseCities()
/*      */   {
/*  347 */     this.cities = new City[this.maxCities];
/*      */ 
/*  352 */     if (0 < this.maxCities) {
/*  353 */       this.cities[0] = new City("Auckland");
/*      */     }
/*  355 */     if (1 < this.maxCities) {
/*  356 */       this.cities[1] = new City("Adelaide");
/*      */     }
/*  358 */     if (2 < this.maxCities) {
/*  359 */       this.cities[2] = new City("Apia");
/*      */     }
/*  361 */     if (3 < this.maxCities) {
/*  362 */       this.cities[3] = new City("Athens");
/*      */     }
/*  364 */     if (4 < this.maxCities) {
/*  365 */       this.cities[4] = new City("Beijing");
/*      */     }
/*  367 */     if (5 < this.maxCities) {
/*  368 */       this.cities[5] = new City("Berlin");
/*      */     }
/*  370 */     if (6 < this.maxCities) {
/*  371 */       this.cities[6] = new City("Buenos Aires");
/*      */     }
/*  373 */     if (7 < this.maxCities) {
/*  374 */       this.cities[7] = new City("Cairo");
/*      */     }
/*  376 */     if (8 < this.maxCities) {
/*  377 */       this.cities[8] = new City("Cancun");
/*      */     }
/*  379 */     if (9 < this.maxCities) {
/*  380 */       this.cities[9] = new City("Chongqing");
/*      */     }
/*  382 */     if (10 < this.maxCities) {
/*  383 */       this.cities[10] = new City("Denpasar");
/*      */     }
/*  385 */     if (11 < this.maxCities) {
/*  386 */       this.cities[11] = new City("Dubai");
/*      */     }
/*  388 */     if (12 < this.maxCities) {
/*  389 */       this.cities[12] = new City("El Paso");
/*      */     }
/*  391 */     if (13 < this.maxCities) {
/*  392 */       this.cities[13] = new City("Frankfurt");
/*      */     }
/*  394 */     if (14 < this.maxCities) {
/*  395 */       this.cities[14] = new City("Geneva");
/*      */     }
/*  397 */     if (15 < this.maxCities) {
/*  398 */       this.cities[15] = new City("Guangdong");
/*      */     }
/*  400 */     if (16 < this.maxCities) {
/*  401 */       this.cities[16] = new City("Hong Kong");
/*      */     }
/*  403 */     if (17 < this.maxCities) {
/*  404 */       this.cities[17] = new City("Honolulu");
/*      */     }
/*  406 */     if (18 < this.maxCities) {
/*  407 */       this.cities[18] = new City("Istanbul");
/*      */     }
/*  409 */     if (19 < this.maxCities) {
/*  410 */       this.cities[19] = new City("Jakarta");
/*      */     }
/*  412 */     if (20 < this.maxCities) {
/*  413 */       this.cities[20] = new City("Jerusalem");
/*      */     }
/*  415 */     if (21 < this.maxCities) {
/*  416 */       this.cities[21] = new City("Johannesburg");
/*      */     }
/*  418 */     if (22 < this.maxCities) {
/*  419 */       this.cities[22] = new City("Kolkata");
/*      */     }
/*  421 */     if (23 < this.maxCities) {
/*  422 */       this.cities[23] = new City("London");
/*      */     }
/*  424 */     if (24 < this.maxCities) {
/*  425 */       this.cities[24] = new City("Los Angeles");
/*      */     }
/*  427 */     if (25 < this.maxCities) {
/*  428 */       this.cities[25] = new City("Manila");
/*      */     }
/*  430 */     if (26 < this.maxCities) {
/*  431 */       this.cities[26] = new City("Melbourne");
/*      */     }
/*  433 */     if (27 < this.maxCities) {
/*  434 */       this.cities[27] = new City("Mexico City");
/*      */     }
/*  436 */     if (28 < this.maxCities) {
/*  437 */       this.cities[28] = new City("Milan");
/*      */     }
/*  439 */     if (29 < this.maxCities) {
/*  440 */       this.cities[29] = new City("Moscow");
/*      */     }
/*  442 */     if (30 < this.maxCities) {
/*  443 */       this.cities[30] = new City("Mumbai");
/*      */     }
/*  445 */     if (31 < this.maxCities) {
/*  446 */       this.cities[31] = new City("Nairobi");
/*      */     }
/*  448 */     if (32 < this.maxCities) {
/*  449 */       this.cities[32] = new City("New York");
/*      */     }
/*  451 */     if (33 < this.maxCities) {
/*  452 */       this.cities[33] = new City("Nice");
/*      */     }
/*  454 */     if (34 < this.maxCities) {
/*  455 */       this.cities[34] = new City("Oslo");
/*      */     }
/*  457 */     if (35 < this.maxCities) {
/*  458 */       this.cities[35] = new City("Paris");
/*      */     }
/*  460 */     if (36 < this.maxCities) {
/*  461 */       this.cities[36] = new City("Perth");
/*      */     }
/*  463 */     if (37 < this.maxCities) {
/*  464 */       this.cities[37] = new City("Quebec");
/*      */     }
/*  466 */     if (38 < this.maxCities) {
/*  467 */       this.cities[38] = new City("Rome");
/*      */     }
/*  469 */     if (39 < this.maxCities) {
/*  470 */       this.cities[39] = new City("Santiago");
/*      */     }
/*  472 */     if (40 < this.maxCities) {
/*  473 */       this.cities[40] = new City("Seoul");
/*      */     }
/*  475 */     if (41 < this.maxCities) {
/*  476 */       this.cities[41] = new City("Shanghai");
/*      */     }
/*  478 */     if (42 < this.maxCities) {
/*  479 */       this.cities[42] = new City("Singapore");
/*      */     }
/*  481 */     if (43 < this.maxCities) {
/*  482 */       this.cities[43] = new City("Sydney");
/*      */     }
/*  484 */     if (44 < this.maxCities) {
/*  485 */       this.cities[44] = new City("Tangiers");
/*      */     }
/*  487 */     if (45 < this.maxCities) {
/*  488 */       this.cities[45] = new City("Tokyo");
/*      */     }
/*  490 */     if (46 < this.maxCities) {
/*  491 */       this.cities[46] = new City("Ulan Bataar");
/*      */     }
/*  493 */     if (47 < this.maxCities) {
/*  494 */       this.cities[47] = new City("Vancouver");
/*      */     }
/*  496 */     if (48 < this.maxCities) {
/*  497 */       this.cities[48] = new City("Venice");
/*      */     }
/*  499 */     if (49 < this.maxCities) {
/*  500 */       this.cities[49] = new City("Vienna");
/*      */     }
/*  502 */     if (50 < this.maxCities) {
/*  503 */       this.cities[50] = new City("Zurich");
/*      */     }
/*      */ 
/*  509 */     this.routeCounter = 0;
/*  510 */     if ((0 < this.maxCities) && (1 < this.maxCities)) {
/*  511 */       this.cities[0].addRoute(1, 297.0D);
/*  512 */       this.routeCounter += 1;
/*  513 */       this.cities[1].addRoute(0, 297.0D);
/*  514 */       this.routeCounter += 1;
/*      */     }
/*  516 */     if ((0 < this.maxCities) && (2 < this.maxCities)) {
/*  517 */       this.cities[0].addRoute(2, 178.19999999999999D);
/*  518 */       this.routeCounter += 1;
/*  519 */       this.cities[2].addRoute(0, 178.19999999999999D);
/*  520 */       this.routeCounter += 1;
/*      */     }
/*  522 */     if ((0 < this.maxCities) && (6 < this.maxCities)) {
/*  523 */       this.cities[0].addRoute(6, 1200.0D);
/*  524 */       this.routeCounter += 1;
/*  525 */       this.cities[6].addRoute(0, 1200.0D);
/*  526 */       this.routeCounter += 1;
/*      */     }
/*  528 */     if ((0 < this.maxCities) && (17 < this.maxCities)) {
/*  529 */       this.cities[0].addRoute(17, 693.0D);
/*  530 */       this.routeCounter += 1;
/*  531 */       this.cities[17].addRoute(0, 693.0D);
/*  532 */       this.routeCounter += 1;
/*      */     }
/*  534 */     if ((0 < this.maxCities) && (24 < this.maxCities)) {
/*  535 */       this.cities[0].addRoute(24, 1138.5D);
/*  536 */       this.routeCounter += 1;
/*  537 */       this.cities[24].addRoute(0, 1138.5D);
/*  538 */       this.routeCounter += 1;
/*      */     }
/*  540 */     if ((0 < this.maxCities) && (36 < this.maxCities)) {
/*  541 */       this.cities[0].addRoute(36, 534.60000000000002D);
/*  542 */       this.routeCounter += 1;
/*  543 */       this.cities[36].addRoute(0, 534.60000000000002D);
/*  544 */       this.routeCounter += 1;
/*      */     }
/*  546 */     if ((0 < this.maxCities) && (39 < this.maxCities)) {
/*  547 */       this.cities[0].addRoute(39, 1089.0D);
/*  548 */       this.routeCounter += 1;
/*  549 */       this.cities[39].addRoute(0, 1089.0D);
/*  550 */       this.routeCounter += 1;
/*      */     }
/*  552 */     if ((0 < this.maxCities) && (40 < this.maxCities)) {
/*  553 */       this.cities[0].addRoute(40, 940.5D);
/*  554 */       this.routeCounter += 1;
/*  555 */       this.cities[40].addRoute(0, 940.5D);
/*  556 */       this.routeCounter += 1;
/*      */     }
/*  558 */     if ((0 < this.maxCities) && (42 < this.maxCities)) {
/*  559 */       this.cities[0].addRoute(42, 990.0D);
/*  560 */       this.routeCounter += 1;
/*  561 */       this.cities[42].addRoute(0, 990.0D);
/*  562 */       this.routeCounter += 1;
/*      */     }
/*  564 */     if ((0 < this.maxCities) && (41 < this.maxCities)) {
/*  565 */       this.cities[0].addRoute(41, 1089.0D);
/*  566 */       this.routeCounter += 1;
/*  567 */       this.cities[41].addRoute(0, 1089.0D);
/*  568 */       this.routeCounter += 1;
/*      */     }
/*  570 */     if ((0 < this.maxCities) && (43 < this.maxCities)) {
/*  571 */       this.cities[0].addRoute(43, 230.0D);
/*  572 */       this.routeCounter += 1;
/*  573 */       this.cities[43].addRoute(0, 230.0D);
/*  574 */       this.routeCounter += 1;
/*      */     }
/*  576 */     if ((0 < this.maxCities) && (45 < this.maxCities)) {
/*  577 */       this.cities[0].addRoute(45, 891.0D);
/*  578 */       this.routeCounter += 1;
/*  579 */       this.cities[45].addRoute(0, 891.0D);
/*  580 */       this.routeCounter += 1;
/*      */     }
/*  582 */     if ((1 < this.maxCities) && (26 < this.maxCities)) {
/*  583 */       this.cities[1].addRoute(26, 100.0D);
/*  584 */       this.routeCounter += 1;
/*  585 */       this.cities[26].addRoute(1, 100.0D);
/*  586 */       this.routeCounter += 1;
/*      */     }
/*  588 */     if ((1 < this.maxCities) && (42 < this.maxCities)) {
/*  589 */       this.cities[1].addRoute(42, 800.0D);
/*  590 */       this.routeCounter += 1;
/*  591 */       this.cities[42].addRoute(1, 800.0D);
/*  592 */       this.routeCounter += 1;
/*      */     }
/*  594 */     if ((1 < this.maxCities) && (43 < this.maxCities)) {
/*  595 */       this.cities[1].addRoute(43, 150.0D);
/*  596 */       this.routeCounter += 1;
/*  597 */       this.cities[43].addRoute(1, 150.0D);
/*  598 */       this.routeCounter += 1;
/*      */     }
/*  600 */     if ((1 < this.maxCities) && (36 < this.maxCities)) {
/*  601 */       this.cities[1].addRoute(36, 250.0D);
/*  602 */       this.routeCounter += 1;
/*  603 */       this.cities[36].addRoute(1, 250.0D);
/*  604 */       this.routeCounter += 1;
/*      */     }
/*  606 */     if ((2 < this.maxCities) && (43 < this.maxCities)) {
/*  607 */       this.cities[2].addRoute(43, 200.0D);
/*  608 */       this.routeCounter += 1;
/*  609 */       this.cities[43].addRoute(2, 200.0D);
/*  610 */       this.routeCounter += 1;
/*      */     }
/*  612 */     if ((2 < this.maxCities) && (26 < this.maxCities)) {
/*  613 */       this.cities[2].addRoute(26, 217.80000000000001D);
/*  614 */       this.routeCounter += 1;
/*  615 */       this.cities[26].addRoute(2, 217.80000000000001D);
/*  616 */       this.routeCounter += 1;
/*      */     }
/*  618 */     if ((3 < this.maxCities) && (42 < this.maxCities)) {
/*  619 */       this.cities[3].addRoute(42, 891.0D);
/*  620 */       this.routeCounter += 1;
/*  621 */       this.cities[42].addRoute(3, 891.0D);
/*  622 */       this.routeCounter += 1;
/*      */     }
/*  624 */     if ((3 < this.maxCities) && (5 < this.maxCities)) {
/*  625 */       this.cities[3].addRoute(5, 148.5D);
/*  626 */       this.routeCounter += 1;
/*  627 */       this.cities[5].addRoute(3, 148.5D);
/*  628 */       this.routeCounter += 1;
/*      */     }
/*  630 */     if ((3 < this.maxCities) && (7 < this.maxCities)) {
/*  631 */       this.cities[3].addRoute(7, 247.5D);
/*  632 */       this.routeCounter += 1;
/*  633 */       this.cities[7].addRoute(3, 247.5D);
/*  634 */       this.routeCounter += 1;
/*      */     }
/*  636 */     if ((3 < this.maxCities) && (11 < this.maxCities)) {
/*  637 */       this.cities[3].addRoute(11, 280.0D);
/*  638 */       this.routeCounter += 1;
/*  639 */       this.cities[11].addRoute(3, 280.0D);
/*  640 */       this.routeCounter += 1;
/*      */     }
/*  642 */     if ((3 < this.maxCities) && (13 < this.maxCities)) {
/*  643 */       this.cities[3].addRoute(13, 148.5D);
/*  644 */       this.routeCounter += 1;
/*  645 */       this.cities[13].addRoute(3, 148.5D);
/*  646 */       this.routeCounter += 1;
/*      */     }
/*  648 */     if ((3 < this.maxCities) && (20 < this.maxCities)) {
/*  649 */       this.cities[3].addRoute(20, 247.5D);
/*  650 */       this.routeCounter += 1;
/*  651 */       this.cities[20].addRoute(3, 247.5D);
/*  652 */       this.routeCounter += 1;
/*      */     }
/*  654 */     if ((3 < this.maxCities) && (23 < this.maxCities)) {
/*  655 */       this.cities[3].addRoute(23, 247.5D);
/*  656 */       this.routeCounter += 1;
/*  657 */       this.cities[23].addRoute(3, 247.5D);
/*  658 */       this.routeCounter += 1;
/*      */     }
/*  660 */     if ((3 < this.maxCities) && (28 < this.maxCities)) {
/*  661 */       this.cities[3].addRoute(28, 99.0D);
/*  662 */       this.routeCounter += 1;
/*  663 */       this.cities[28].addRoute(3, 99.0D);
/*  664 */       this.routeCounter += 1;
/*      */     }
/*  666 */     if ((3 < this.maxCities) && (29 < this.maxCities)) {
/*  667 */       this.cities[3].addRoute(29, 297.0D);
/*  668 */       this.routeCounter += 1;
/*  669 */       this.cities[29].addRoute(3, 297.0D);
/*  670 */       this.routeCounter += 1;
/*      */     }
/*  672 */     if ((3 < this.maxCities) && (32 < this.maxCities)) {
/*  673 */       this.cities[3].addRoute(32, 1089.0D);
/*  674 */       this.routeCounter += 1;
/*  675 */       this.cities[32].addRoute(3, 1089.0D);
/*  676 */       this.routeCounter += 1;
/*      */     }
/*  678 */     if ((3 < this.maxCities) && (35 < this.maxCities)) {
/*  679 */       this.cities[3].addRoute(35, 198.0D);
/*  680 */       this.routeCounter += 1;
/*  681 */       this.cities[35].addRoute(3, 198.0D);
/*  682 */       this.routeCounter += 1;
/*      */     }
/*  684 */     if ((3 < this.maxCities) && (49 < this.maxCities)) {
/*  685 */       this.cities[3].addRoute(49, 138.59999999999999D);
/*  686 */       this.routeCounter += 1;
/*  687 */       this.cities[49].addRoute(3, 138.59999999999999D);
/*  688 */       this.routeCounter += 1;
/*      */     }
/*  690 */     if ((4 < this.maxCities) && (5 < this.maxCities)) {
/*  691 */       this.cities[4].addRoute(5, 1000.0D);
/*  692 */       this.routeCounter += 1;
/*  693 */       this.cities[5].addRoute(4, 1000.0D);
/*  694 */       this.routeCounter += 1;
/*      */     }
/*  696 */     if ((4 < this.maxCities) && (9 < this.maxCities)) {
/*  697 */       this.cities[4].addRoute(9, 200.0D);
/*  698 */       this.routeCounter += 1;
/*  699 */       this.cities[9].addRoute(4, 200.0D);
/*  700 */       this.routeCounter += 1;
/*      */     }
/*  702 */     if ((4 < this.maxCities) && (11 < this.maxCities)) {
/*  703 */       this.cities[4].addRoute(11, 950.0D);
/*  704 */       this.routeCounter += 1;
/*  705 */       this.cities[11].addRoute(4, 950.0D);
/*  706 */       this.routeCounter += 1;
/*      */     }
/*  708 */     if ((4 < this.maxCities) && (14 < this.maxCities)) {
/*  709 */       this.cities[4].addRoute(14, 1050.0D);
/*  710 */       this.routeCounter += 1;
/*  711 */       this.cities[14].addRoute(4, 1050.0D);
/*  712 */       this.routeCounter += 1;
/*      */     }
/*  714 */     if ((4 < this.maxCities) && (15 < this.maxCities)) {
/*  715 */       this.cities[4].addRoute(15, 150.0D);
/*  716 */       this.routeCounter += 1;
/*  717 */       this.cities[15].addRoute(4, 150.0D);
/*  718 */       this.routeCounter += 1;
/*      */     }
/*  720 */     if ((4 < this.maxCities) && (16 < this.maxCities)) {
/*  721 */       this.cities[4].addRoute(16, 160.0D);
/*  722 */       this.routeCounter += 1;
/*  723 */       this.cities[16].addRoute(4, 160.0D);
/*  724 */       this.routeCounter += 1;
/*      */     }
/*  726 */     if ((4 < this.maxCities) && (17 < this.maxCities)) {
/*  727 */       this.cities[4].addRoute(17, 650.0D);
/*  728 */       this.routeCounter += 1;
/*  729 */       this.cities[17].addRoute(4, 650.0D);
/*  730 */       this.routeCounter += 1;
/*      */     }
/*  732 */     if ((4 < this.maxCities) && (19 < this.maxCities)) {
/*  733 */       this.cities[4].addRoute(19, 346.5D);
/*  734 */       this.routeCounter += 1;
/*  735 */       this.cities[19].addRoute(4, 346.5D);
/*  736 */       this.routeCounter += 1;
/*      */     }
/*  738 */     if ((4 < this.maxCities) && (22 < this.maxCities)) {
/*  739 */       this.cities[4].addRoute(22, 400.0D);
/*  740 */       this.routeCounter += 1;
/*  741 */       this.cities[22].addRoute(4, 400.0D);
/*  742 */       this.routeCounter += 1;
/*      */     }
/*  744 */     if ((4 < this.maxCities) && (23 < this.maxCities)) {
/*  745 */       this.cities[4].addRoute(23, 1050.0D);
/*  746 */       this.routeCounter += 1;
/*  747 */       this.cities[23].addRoute(4, 1050.0D);
/*  748 */       this.routeCounter += 1;
/*      */     }
/*  750 */     if ((4 < this.maxCities) && (24 < this.maxCities)) {
/*  751 */       this.cities[4].addRoute(24, 1250.0D);
/*  752 */       this.routeCounter += 1;
/*  753 */       this.cities[24].addRoute(4, 1250.0D);
/*  754 */       this.routeCounter += 1;
/*      */     }
/*  756 */     if ((4 < this.maxCities) && (25 < this.maxCities)) {
/*  757 */       this.cities[4].addRoute(25, 198.0D);
/*  758 */       this.routeCounter += 1;
/*  759 */       this.cities[25].addRoute(4, 198.0D);
/*  760 */       this.routeCounter += 1;
/*      */     }
/*  762 */     if ((4 < this.maxCities) && (26 < this.maxCities)) {
/*  763 */       this.cities[4].addRoute(26, 650.0D);
/*  764 */       this.routeCounter += 1;
/*  765 */       this.cities[26].addRoute(4, 650.0D);
/*  766 */       this.routeCounter += 1;
/*      */     }
/*  768 */     if ((4 < this.maxCities) && (27 < this.maxCities)) {
/*  769 */       this.cities[4].addRoute(27, 1300.0D);
/*  770 */       this.routeCounter += 1;
/*  771 */       this.cities[27].addRoute(4, 1300.0D);
/*  772 */       this.routeCounter += 1;
/*      */     }
/*  774 */     if ((4 < this.maxCities) && (28 < this.maxCities)) {
/*  775 */       this.cities[4].addRoute(28, 1200.0D);
/*  776 */       this.routeCounter += 1;
/*  777 */       this.cities[28].addRoute(4, 1200.0D);
/*  778 */       this.routeCounter += 1;
/*      */     }
/*  780 */     if ((4 < this.maxCities) && (29 < this.maxCities)) {
/*  781 */       this.cities[4].addRoute(29, 1000.0D);
/*  782 */       this.routeCounter += 1;
/*  783 */       this.cities[29].addRoute(4, 1000.0D);
/*  784 */       this.routeCounter += 1;
/*      */     }
/*  786 */     if ((4 < this.maxCities) && (30 < this.maxCities)) {
/*  787 */       this.cities[4].addRoute(30, 450.0D);
/*  788 */       this.routeCounter += 1;
/*  789 */       this.cities[30].addRoute(4, 450.0D);
/*  790 */       this.routeCounter += 1;
/*      */     }
/*  792 */     if ((4 < this.maxCities) && (32 < this.maxCities)) {
/*  793 */       this.cities[4].addRoute(32, 1200.0D);
/*  794 */       this.routeCounter += 1;
/*  795 */       this.cities[32].addRoute(4, 1200.0D);
/*  796 */       this.routeCounter += 1;
/*      */     }
/*  798 */     if ((4 < this.maxCities) && (34 < this.maxCities)) {
/*  799 */       this.cities[4].addRoute(34, 1000.0D);
/*  800 */       this.routeCounter += 1;
/*  801 */       this.cities[34].addRoute(4, 1000.0D);
/*  802 */       this.routeCounter += 1;
/*      */     }
/*  804 */     if ((4 < this.maxCities) && (35 < this.maxCities)) {
/*  805 */       this.cities[4].addRoute(35, 1089.0D);
/*  806 */       this.routeCounter += 1;
/*  807 */       this.cities[35].addRoute(4, 1089.0D);
/*  808 */       this.routeCounter += 1;
/*      */     }
/*  810 */     if ((4 < this.maxCities) && (38 < this.maxCities)) {
/*  811 */       this.cities[4].addRoute(38, 1150.0D);
/*  812 */       this.routeCounter += 1;
/*  813 */       this.cities[38].addRoute(4, 1150.0D);
/*  814 */       this.routeCounter += 1;
/*      */     }
/*  816 */     if ((4 < this.maxCities) && (32 < this.maxCities)) {
/*  817 */       this.cities[4].addRoute(32, 1200.0D);
/*  818 */       this.routeCounter += 1;
/*  819 */       this.cities[32].addRoute(4, 1200.0D);
/*  820 */       this.routeCounter += 1;
/*      */     }
/*  822 */     if ((4 < this.maxCities) && (41 < this.maxCities)) {
/*  823 */       this.cities[4].addRoute(41, 200.0D);
/*  824 */       this.routeCounter += 1;
/*  825 */       this.cities[41].addRoute(4, 200.0D);
/*  826 */       this.routeCounter += 1;
/*      */     }
/*  828 */     if ((4 < this.maxCities) && (42 < this.maxCities)) {
/*  829 */       this.cities[4].addRoute(42, 350.0D);
/*  830 */       this.routeCounter += 1;
/*  831 */       this.cities[42].addRoute(4, 350.0D);
/*  832 */       this.routeCounter += 1;
/*      */     }
/*  834 */     if ((4 < this.maxCities) && (45 < this.maxCities)) {
/*  835 */       this.cities[4].addRoute(45, 200.0D);
/*  836 */       this.routeCounter += 1;
/*  837 */       this.cities[45].addRoute(4, 200.0D);
/*  838 */       this.routeCounter += 1;
/*      */     }
/*  840 */     if ((4 < this.maxCities) && (46 < this.maxCities)) {
/*  841 */       this.cities[4].addRoute(46, 250.0D);
/*  842 */       this.routeCounter += 1;
/*  843 */       this.cities[46].addRoute(4, 250.0D);
/*  844 */       this.routeCounter += 1;
/*      */     }
/*  846 */     if ((4 < this.maxCities) && (47 < this.maxCities)) {
/*  847 */       this.cities[4].addRoute(47, 891.0D);
/*  848 */       this.routeCounter += 1;
/*  849 */       this.cities[47].addRoute(4, 891.0D);
/*  850 */       this.routeCounter += 1;
/*      */     }
/*  852 */     if ((4 < this.maxCities) && (50 < this.maxCities)) {
/*  853 */       this.cities[4].addRoute(50, 1300.0D);
/*  854 */       this.routeCounter += 1;
/*  855 */       this.cities[50].addRoute(4, 1300.0D);
/*  856 */       this.routeCounter += 1;
/*      */     }
/*  858 */     if ((5 < this.maxCities) && (13 < this.maxCities)) {
/*  859 */       this.cities[5].addRoute(13, 100.0D);
/*  860 */       this.routeCounter += 1;
/*  861 */       this.cities[13].addRoute(5, 100.0D);
/*  862 */       this.routeCounter += 1;
/*      */     }
/*  864 */     if ((5 < this.maxCities) && (14 < this.maxCities)) {
/*  865 */       this.cities[5].addRoute(14, 120.0D);
/*  866 */       this.routeCounter += 1;
/*  867 */       this.cities[14].addRoute(5, 120.0D);
/*  868 */       this.routeCounter += 1;
/*      */     }
/*  870 */     if ((5 < this.maxCities) && (18 < this.maxCities)) {
/*  871 */       this.cities[5].addRoute(18, 220.0D);
/*  872 */       this.routeCounter += 1;
/*  873 */       this.cities[18].addRoute(5, 220.0D);
/*  874 */       this.routeCounter += 1;
/*      */     }
/*  876 */     if ((5 < this.maxCities) && (20 < this.maxCities)) {
/*  877 */       this.cities[5].addRoute(20, 250.0D);
/*  878 */       this.routeCounter += 1;
/*  879 */       this.cities[20].addRoute(5, 250.0D);
/*  880 */       this.routeCounter += 1;
/*      */     }
/*  882 */     if ((5 < this.maxCities) && (23 < this.maxCities)) {
/*  883 */       this.cities[5].addRoute(23, 150.0D);
/*  884 */       this.routeCounter += 1;
/*  885 */       this.cities[23].addRoute(5, 150.0D);
/*  886 */       this.routeCounter += 1;
/*      */     }
/*  888 */     if ((5 < this.maxCities) && (28 < this.maxCities)) {
/*  889 */       this.cities[5].addRoute(28, 250.0D);
/*  890 */       this.routeCounter += 1;
/*  891 */       this.cities[28].addRoute(5, 250.0D);
/*  892 */       this.routeCounter += 1;
/*      */     }
/*  894 */     if ((5 < this.maxCities) && (29 < this.maxCities)) {
/*  895 */       this.cities[5].addRoute(29, 350.0D);
/*  896 */       this.routeCounter += 1;
/*  897 */       this.cities[29].addRoute(5, 350.0D);
/*  898 */       this.routeCounter += 1;
/*      */     }
/*  900 */     if ((5 < this.maxCities) && (31 < this.maxCities)) {
/*  901 */       this.cities[5].addRoute(31, 792.0D);
/*  902 */       this.routeCounter += 1;
/*  903 */       this.cities[31].addRoute(5, 792.0D);
/*  904 */       this.routeCounter += 1;
/*      */     }
/*  906 */     if ((5 < this.maxCities) && (32 < this.maxCities)) {
/*  907 */       this.cities[5].addRoute(32, 700.0D);
/*  908 */       this.routeCounter += 1;
/*  909 */       this.cities[32].addRoute(5, 700.0D);
/*  910 */       this.routeCounter += 1;
/*      */     }
/*  912 */     if ((5 < this.maxCities) && (34 < this.maxCities)) {
/*  913 */       this.cities[5].addRoute(34, 120.0D);
/*  914 */       this.routeCounter += 1;
/*  915 */       this.cities[34].addRoute(5, 120.0D);
/*  916 */       this.routeCounter += 1;
/*      */     }
/*  918 */     if ((5 < this.maxCities) && (35 < this.maxCities)) {
/*  919 */       this.cities[5].addRoute(35, 148.5D);
/*  920 */       this.routeCounter += 1;
/*  921 */       this.cities[35].addRoute(5, 148.5D);
/*  922 */       this.routeCounter += 1;
/*      */     }
/*  924 */     if ((5 < this.maxCities) && (38 < this.maxCities)) {
/*  925 */       this.cities[5].addRoute(38, 400.0D);
/*  926 */       this.routeCounter += 1;
/*  927 */       this.cities[38].addRoute(5, 400.0D);
/*  928 */       this.routeCounter += 1;
/*      */     }
/*  930 */     if ((5 < this.maxCities) && (45 < this.maxCities)) {
/*  931 */       this.cities[5].addRoute(45, 1500.0D);
/*  932 */       this.routeCounter += 1;
/*  933 */       this.cities[45].addRoute(5, 1500.0D);
/*  934 */       this.routeCounter += 1;
/*      */     }
/*  936 */     if ((5 < this.maxCities) && (49 < this.maxCities)) {
/*  937 */       this.cities[5].addRoute(49, 300.0D);
/*  938 */       this.routeCounter += 1;
/*  939 */       this.cities[49].addRoute(5, 300.0D);
/*  940 */       this.routeCounter += 1;
/*      */     }
/*  942 */     if ((5 < this.maxCities) && (50 < this.maxCities)) {
/*  943 */       this.cities[5].addRoute(50, 200.0D);
/*  944 */       this.routeCounter += 1;
/*  945 */       this.cities[50].addRoute(5, 200.0D);
/*  946 */       this.routeCounter += 1;
/*      */     }
/*  948 */     if ((6 < this.maxCities) && (13 < this.maxCities)) {
/*  949 */       this.cities[6].addRoute(13, 1485.0D);
/*  950 */       this.routeCounter += 1;
/*  951 */       this.cities[13].addRoute(6, 1485.0D);
/*  952 */       this.routeCounter += 1;
/*      */     }
/*  954 */     if ((6 < this.maxCities) && (14 < this.maxCities)) {
/*  955 */       this.cities[6].addRoute(14, 1386.0D);
/*  956 */       this.routeCounter += 1;
/*  957 */       this.cities[14].addRoute(6, 1386.0D);
/*  958 */       this.routeCounter += 1;
/*      */     }
/*  960 */     if ((6 < this.maxCities) && (17 < this.maxCities)) {
/*  961 */       this.cities[6].addRoute(17, 1188.0D);
/*  962 */       this.routeCounter += 1;
/*  963 */       this.cities[17].addRoute(6, 1188.0D);
/*  964 */       this.routeCounter += 1;
/*      */     }
/*  966 */     if ((6 < this.maxCities) && (21 < this.maxCities)) {
/*  967 */       this.cities[6].addRoute(21, 990.0D);
/*  968 */       this.routeCounter += 1;
/*  969 */       this.cities[21].addRoute(6, 990.0D);
/*  970 */       this.routeCounter += 1;
/*      */     }
/*  972 */     if ((6 < this.maxCities) && (23 < this.maxCities)) {
/*  973 */       this.cities[6].addRoute(23, 1435.5D);
/*  974 */       this.routeCounter += 1;
/*  975 */       this.cities[23].addRoute(6, 1435.5D);
/*  976 */       this.routeCounter += 1;
/*      */     }
/*  978 */     if ((6 < this.maxCities) && (24 < this.maxCities)) {
/*  979 */       this.cities[6].addRoute(24, 990.0D);
/*  980 */       this.routeCounter += 1;
/*  981 */       this.cities[24].addRoute(6, 990.0D);
/*  982 */       this.routeCounter += 1;
/*      */     }
/*  984 */     if ((6 < this.maxCities) && (27 < this.maxCities)) {
/*  985 */       this.cities[6].addRoute(27, 990.0D);
/*  986 */       this.routeCounter += 1;
/*  987 */       this.cities[27].addRoute(6, 990.0D);
/*  988 */       this.routeCounter += 1;
/*      */     }
/*  990 */     if ((6 < this.maxCities) && (32 < this.maxCities)) {
/*  991 */       this.cities[6].addRoute(32, 1386.0D);
/*  992 */       this.routeCounter += 1;
/*  993 */       this.cities[32].addRoute(6, 1386.0D);
/*  994 */       this.routeCounter += 1;
/*      */     }
/*  996 */     if ((6 < this.maxCities) && (35 < this.maxCities)) {
/*  997 */       this.cities[6].addRoute(35, 1386.0D);
/*  998 */       this.routeCounter += 1;
/*  999 */       this.cities[35].addRoute(6, 1386.0D);
/* 1000 */       this.routeCounter += 1;
/*      */     }
/* 1002 */     if ((6 < this.maxCities) && (37 < this.maxCities)) {
/* 1003 */       this.cities[6].addRoute(37, 1500.0D);
/* 1004 */       this.routeCounter += 1;
/* 1005 */       this.cities[37].addRoute(6, 1500.0D);
/* 1006 */       this.routeCounter += 1;
/*      */     }
/* 1008 */     if ((6 < this.maxCities) && (38 < this.maxCities)) {
/* 1009 */       this.cities[6].addRoute(38, 1435.5D);
/* 1010 */       this.routeCounter += 1;
/* 1011 */       this.cities[38].addRoute(6, 1435.5D);
/* 1012 */       this.routeCounter += 1;
/*      */     }
/* 1014 */     if ((6 < this.maxCities) && (39 < this.maxCities)) {
/* 1015 */       this.cities[6].addRoute(39, 445.5D);
/* 1016 */       this.routeCounter += 1;
/* 1017 */       this.cities[39].addRoute(6, 445.5D);
/* 1018 */       this.routeCounter += 1;
/*      */     }
/* 1020 */     if ((7 < this.maxCities) && (11 < this.maxCities)) {
/* 1021 */       this.cities[7].addRoute(11, 250.0D);
/* 1022 */       this.routeCounter += 1;
/* 1023 */       this.cities[11].addRoute(7, 250.0D);
/* 1024 */       this.routeCounter += 1;
/*      */     }
/* 1026 */     if ((7 < this.maxCities) && (13 < this.maxCities)) {
/* 1027 */       this.cities[7].addRoute(13, 250.0D);
/* 1028 */       this.routeCounter += 1;
/* 1029 */       this.cities[13].addRoute(7, 250.0D);
/* 1030 */       this.routeCounter += 1;
/*      */     }
/* 1032 */     if ((7 < this.maxCities) && (14 < this.maxCities)) {
/* 1033 */       this.cities[7].addRoute(14, 350.0D);
/* 1034 */       this.routeCounter += 1;
/* 1035 */       this.cities[14].addRoute(7, 350.0D);
/* 1036 */       this.routeCounter += 1;
/*      */     }
/* 1038 */     if ((7 < this.maxCities) && (16 < this.maxCities)) {
/* 1039 */       this.cities[7].addRoute(16, 1350.0D);
/* 1040 */       this.routeCounter += 1;
/* 1041 */       this.cities[16].addRoute(7, 1350.0D);
/* 1042 */       this.routeCounter += 1;
/*      */     }
/* 1044 */     if ((7 < this.maxCities) && (18 < this.maxCities)) {
/* 1045 */       this.cities[7].addRoute(18, 200.0D);
/* 1046 */       this.routeCounter += 1;
/* 1047 */       this.cities[18].addRoute(7, 200.0D);
/* 1048 */       this.routeCounter += 1;
/*      */     }
/* 1050 */     if ((7 < this.maxCities) && (20 < this.maxCities)) {
/* 1051 */       this.cities[7].addRoute(20, 400.0D);
/* 1052 */       this.routeCounter += 1;
/* 1053 */       this.cities[20].addRoute(7, 400.0D);
/* 1054 */       this.routeCounter += 1;
/*      */     }
/* 1056 */     if ((7 < this.maxCities) && (21 < this.maxCities)) {
/* 1057 */       this.cities[7].addRoute(21, 900.0D);
/* 1058 */       this.routeCounter += 1;
/* 1059 */       this.cities[21].addRoute(7, 900.0D);
/* 1060 */       this.routeCounter += 1;
/*      */     }
/* 1062 */     if ((7 < this.maxCities) && (23 < this.maxCities)) {
/* 1063 */       this.cities[7].addRoute(23, 300.0D);
/* 1064 */       this.routeCounter += 1;
/* 1065 */       this.cities[23].addRoute(7, 300.0D);
/* 1066 */       this.routeCounter += 1;
/*      */     }
/* 1068 */     if ((7 < this.maxCities) && (28 < this.maxCities)) {
/* 1069 */       this.cities[7].addRoute(28, 300.0D);
/* 1070 */       this.routeCounter += 1;
/* 1071 */       this.cities[28].addRoute(7, 300.0D);
/* 1072 */       this.routeCounter += 1;
/*      */     }
/* 1074 */     if ((7 < this.maxCities) && (31 < this.maxCities)) {
/* 1075 */       this.cities[7].addRoute(31, 350.0D);
/* 1076 */       this.routeCounter += 1;
/* 1077 */       this.cities[31].addRoute(7, 350.0D);
/* 1078 */       this.routeCounter += 1;
/*      */     }
/* 1080 */     if ((7 < this.maxCities) && (32 < this.maxCities)) {
/* 1081 */       this.cities[7].addRoute(32, 1500.0D);
/* 1082 */       this.routeCounter += 1;
/* 1083 */       this.cities[32].addRoute(7, 1500.0D);
/* 1084 */       this.routeCounter += 1;
/*      */     }
/* 1086 */     if ((7 < this.maxCities) && (35 < this.maxCities)) {
/* 1087 */       this.cities[7].addRoute(35, 500.0D);
/* 1088 */       this.routeCounter += 1;
/* 1089 */       this.cities[35].addRoute(7, 500.0D);
/* 1090 */       this.routeCounter += 1;
/*      */     }
/* 1092 */     if ((7 < this.maxCities) && (38 < this.maxCities)) {
/* 1093 */       this.cities[7].addRoute(38, 300.0D);
/* 1094 */       this.routeCounter += 1;
/* 1095 */       this.cities[38].addRoute(7, 300.0D);
/* 1096 */       this.routeCounter += 1;
/*      */     }
/* 1098 */     if ((7 < this.maxCities) && (44 < this.maxCities)) {
/* 1099 */       this.cities[7].addRoute(44, 350.0D);
/* 1100 */       this.routeCounter += 1;
/* 1101 */       this.cities[44].addRoute(7, 350.0D);
/* 1102 */       this.routeCounter += 1;
/*      */     }
/* 1104 */     if ((7 < this.maxCities) && (49 < this.maxCities)) {
/* 1105 */       this.cities[7].addRoute(49, 400.0D);
/* 1106 */       this.routeCounter += 1;
/* 1107 */       this.cities[49].addRoute(7, 400.0D);
/* 1108 */       this.routeCounter += 1;
/*      */     }
/* 1110 */     if ((8 < this.maxCities) && (27 < this.maxCities)) {
/* 1111 */       this.cities[8].addRoute(27, 150.0D);
/* 1112 */       this.routeCounter += 1;
/* 1113 */       this.cities[27].addRoute(8, 150.0D);
/* 1114 */       this.routeCounter += 1;
/*      */     }
/* 1116 */     if ((8 < this.maxCities) && (32 < this.maxCities)) {
/* 1117 */       this.cities[8].addRoute(32, 400.0D);
/* 1118 */       this.routeCounter += 1;
/* 1119 */       this.cities[32].addRoute(8, 400.0D);
/* 1120 */       this.routeCounter += 1;
/*      */     }
/* 1122 */     if ((8 < this.maxCities) && (24 < this.maxCities)) {
/* 1123 */       this.cities[8].addRoute(24, 350.0D);
/* 1124 */       this.routeCounter += 1;
/* 1125 */       this.cities[24].addRoute(8, 350.0D);
/* 1126 */       this.routeCounter += 1;
/*      */     }
/* 1128 */     if ((8 < this.maxCities) && (47 < this.maxCities)) {
/* 1129 */       this.cities[8].addRoute(47, 500.0D);
/* 1130 */       this.routeCounter += 1;
/* 1131 */       this.cities[47].addRoute(8, 500.0D);
/* 1132 */       this.routeCounter += 1;
/*      */     }
/* 1134 */     if ((9 < this.maxCities) && (11 < this.maxCities)) {
/* 1135 */       this.cities[9].addRoute(11, 1200.0D);
/* 1136 */       this.routeCounter += 1;
/* 1137 */       this.cities[11].addRoute(9, 1200.0D);
/* 1138 */       this.routeCounter += 1;
/*      */     }
/* 1140 */     if ((9 < this.maxCities) && (15 < this.maxCities)) {
/* 1141 */       this.cities[9].addRoute(15, 150.0D);
/* 1142 */       this.routeCounter += 1;
/* 1143 */       this.cities[15].addRoute(9, 150.0D);
/* 1144 */       this.routeCounter += 1;
/*      */     }
/* 1146 */     if ((9 < this.maxCities) && (41 < this.maxCities)) {
/* 1147 */       this.cities[9].addRoute(41, 200.0D);
/* 1148 */       this.routeCounter += 1;
/* 1149 */       this.cities[41].addRoute(9, 200.0D);
/* 1150 */       this.routeCounter += 1;
/*      */     }
/* 1152 */     if ((10 < this.maxCities) && (11 < this.maxCities)) {
/* 1153 */       this.cities[10].addRoute(11, 1200.0D);
/* 1154 */       this.routeCounter += 1;
/* 1155 */       this.cities[11].addRoute(10, 1200.0D);
/* 1156 */       this.routeCounter += 1;
/*      */     }
/* 1158 */     if ((10 < this.maxCities) && (42 < this.maxCities)) {
/* 1159 */       this.cities[10].addRoute(42, 400.0D);
/* 1160 */       this.routeCounter += 1;
/* 1161 */       this.cities[42].addRoute(10, 400.0D);
/* 1162 */       this.routeCounter += 1;
/*      */     }
/* 1164 */     if ((10 < this.maxCities) && (19 < this.maxCities)) {
/* 1165 */       this.cities[10].addRoute(19, 198.0D);
/* 1166 */       this.routeCounter += 1;
/* 1167 */       this.cities[19].addRoute(10, 198.0D);
/* 1168 */       this.routeCounter += 1;
/*      */     }
/* 1170 */     if ((11 < this.maxCities) && (13 < this.maxCities)) {
/* 1171 */       this.cities[11].addRoute(13, 891.0D);
/* 1172 */       this.routeCounter += 1;
/* 1173 */       this.cities[13].addRoute(11, 891.0D);
/* 1174 */       this.routeCounter += 1;
/*      */     }
/* 1176 */     if ((11 < this.maxCities) && (14 < this.maxCities)) {
/* 1177 */       this.cities[11].addRoute(14, 792.0D);
/* 1178 */       this.routeCounter += 1;
/* 1179 */       this.cities[14].addRoute(11, 792.0D);
/* 1180 */       this.routeCounter += 1;
/*      */     }
/* 1182 */     if ((11 < this.maxCities) && (16 < this.maxCities)) {
/* 1183 */       this.cities[11].addRoute(16, 990.0D);
/* 1184 */       this.routeCounter += 1;
/* 1185 */       this.cities[16].addRoute(11, 990.0D);
/* 1186 */       this.routeCounter += 1;
/*      */     }
/* 1188 */     if ((11 < this.maxCities) && (18 < this.maxCities)) {
/* 1189 */       this.cities[11].addRoute(18, 247.5D);
/* 1190 */       this.routeCounter += 1;
/* 1191 */       this.cities[18].addRoute(11, 247.5D);
/* 1192 */       this.routeCounter += 1;
/*      */     }
/* 1194 */     if ((11 < this.maxCities) && (19 < this.maxCities)) {
/* 1195 */       this.cities[11].addRoute(19, 990.0D);
/* 1196 */       this.routeCounter += 1;
/* 1197 */       this.cities[19].addRoute(11, 990.0D);
/* 1198 */       this.routeCounter += 1;
/*      */     }
/* 1200 */     if ((11 < this.maxCities) && (21 < this.maxCities)) {
/* 1201 */       this.cities[11].addRoute(21, 1188.0D);
/* 1202 */       this.routeCounter += 1;
/* 1203 */       this.cities[21].addRoute(11, 1188.0D);
/* 1204 */       this.routeCounter += 1;
/*      */     }
/* 1206 */     if ((11 < this.maxCities) && (22 < this.maxCities)) {
/* 1207 */       this.cities[11].addRoute(22, 891.0D);
/* 1208 */       this.routeCounter += 1;
/* 1209 */       this.cities[22].addRoute(11, 891.0D);
/* 1210 */       this.routeCounter += 1;
/*      */     }
/* 1212 */     if ((11 < this.maxCities) && (23 < this.maxCities)) {
/* 1213 */       this.cities[11].addRoute(23, 940.5D);
/* 1214 */       this.routeCounter += 1;
/* 1215 */       this.cities[23].addRoute(11, 940.5D);
/* 1216 */       this.routeCounter += 1;
/*      */     }
/* 1218 */     if ((11 < this.maxCities) && (24 < this.maxCities)) {
/* 1219 */       this.cities[11].addRoute(24, 1584.0D);
/* 1220 */       this.routeCounter += 1;
/* 1221 */       this.cities[24].addRoute(11, 1584.0D);
/* 1222 */       this.routeCounter += 1;
/*      */     }
/* 1224 */     if ((11 < this.maxCities) && (26 < this.maxCities)) {
/* 1225 */       this.cities[11].addRoute(26, 1287.0D);
/* 1226 */       this.routeCounter += 1;
/* 1227 */       this.cities[26].addRoute(11, 1287.0D);
/* 1228 */       this.routeCounter += 1;
/*      */     }
/* 1230 */     if ((11 < this.maxCities) && (28 < this.maxCities)) {
/* 1231 */       this.cities[11].addRoute(28, 792.0D);
/* 1232 */       this.routeCounter += 1;
/* 1233 */       this.cities[28].addRoute(11, 792.0D);
/* 1234 */       this.routeCounter += 1;
/*      */     }
/* 1236 */     if ((11 < this.maxCities) && (29 < this.maxCities)) {
/* 1237 */       this.cities[11].addRoute(29, 792.0D);
/* 1238 */       this.routeCounter += 1;
/* 1239 */       this.cities[29].addRoute(11, 792.0D);
/* 1240 */       this.routeCounter += 1;
/*      */     }
/* 1242 */     if ((11 < this.maxCities) && (30 < this.maxCities)) {
/* 1243 */       this.cities[11].addRoute(30, 800.0D);
/* 1244 */       this.routeCounter += 1;
/* 1245 */       this.cities[30].addRoute(11, 800.0D);
/* 1246 */       this.routeCounter += 1;
/*      */     }
/* 1248 */     if ((11 < this.maxCities) && (31 < this.maxCities)) {
/* 1249 */       this.cities[11].addRoute(31, 495.0D);
/* 1250 */       this.routeCounter += 1;
/* 1251 */       this.cities[31].addRoute(11, 495.0D);
/* 1252 */       this.routeCounter += 1;
/*      */     }
/* 1254 */     if ((11 < this.maxCities) && (32 < this.maxCities)) {
/* 1255 */       this.cities[11].addRoute(32, 1386.0D);
/* 1256 */       this.routeCounter += 1;
/* 1257 */       this.cities[32].addRoute(11, 1386.0D);
/* 1258 */       this.routeCounter += 1;
/*      */     }
/* 1260 */     if ((11 < this.maxCities) && (33 < this.maxCities)) {
/* 1261 */       this.cities[11].addRoute(33, 792.0D);
/* 1262 */       this.routeCounter += 1;
/* 1263 */       this.cities[33].addRoute(11, 792.0D);
/* 1264 */       this.routeCounter += 1;
/*      */     }
/* 1266 */     if ((11 < this.maxCities) && (34 < this.maxCities)) {
/* 1267 */       this.cities[11].addRoute(34, 891.0D);
/* 1268 */       this.routeCounter += 1;
/* 1269 */       this.cities[34].addRoute(11, 891.0D);
/* 1270 */       this.routeCounter += 1;
/*      */     }
/* 1272 */     if ((11 < this.maxCities) && (35 < this.maxCities)) {
/* 1273 */       this.cities[11].addRoute(35, 841.5D);
/* 1274 */       this.routeCounter += 1;
/* 1275 */       this.cities[35].addRoute(11, 841.5D);
/* 1276 */       this.routeCounter += 1;
/*      */     }
/* 1278 */     if ((11 < this.maxCities) && (36 < this.maxCities)) {
/* 1279 */       this.cities[11].addRoute(36, 940.5D);
/* 1280 */       this.routeCounter += 1;
/* 1281 */       this.cities[36].addRoute(11, 940.5D);
/* 1282 */       this.routeCounter += 1;
/*      */     }
/* 1284 */     if ((11 < this.maxCities) && (38 < this.maxCities)) {
/* 1285 */       this.cities[11].addRoute(38, 445.5D);
/* 1286 */       this.routeCounter += 1;
/* 1287 */       this.cities[38].addRoute(11, 445.5D);
/* 1288 */       this.routeCounter += 1;
/*      */     }
/* 1290 */     if ((11 < this.maxCities) && (42 < this.maxCities)) {
/* 1291 */       this.cities[11].addRoute(42, 891.0D);
/* 1292 */       this.routeCounter += 1;
/* 1293 */       this.cities[42].addRoute(11, 891.0D);
/* 1294 */       this.routeCounter += 1;
/*      */     }
/* 1296 */     if ((11 < this.maxCities) && (43 < this.maxCities)) {
/* 1297 */       this.cities[11].addRoute(43, 1250.0D);
/* 1298 */       this.routeCounter += 1;
/* 1299 */       this.cities[43].addRoute(11, 1250.0D);
/* 1300 */       this.routeCounter += 1;
/*      */     }
/* 1302 */     if ((11 < this.maxCities) && (44 < this.maxCities)) {
/* 1303 */       this.cities[11].addRoute(44, 594.0D);
/* 1304 */       this.routeCounter += 1;
/* 1305 */       this.cities[44].addRoute(11, 594.0D);
/* 1306 */       this.routeCounter += 1;
/*      */     }
/* 1308 */     if ((11 < this.maxCities) && (45 < this.maxCities)) {
/* 1309 */       this.cities[11].addRoute(45, 1287.0D);
/* 1310 */       this.routeCounter += 1;
/* 1311 */       this.cities[45].addRoute(11, 1287.0D);
/* 1312 */       this.routeCounter += 1;
/*      */     }
/* 1314 */     if ((11 < this.maxCities) && (49 < this.maxCities)) {
/* 1315 */       this.cities[11].addRoute(49, 742.5D);
/* 1316 */       this.routeCounter += 1;
/* 1317 */       this.cities[49].addRoute(11, 742.5D);
/* 1318 */       this.routeCounter += 1;
/*      */     }
/* 1320 */     if ((12 < this.maxCities) && (24 < this.maxCities)) {
/* 1321 */       this.cities[12].addRoute(24, 150.0D);
/* 1322 */       this.routeCounter += 1;
/* 1323 */       this.cities[24].addRoute(12, 150.0D);
/* 1324 */       this.routeCounter += 1;
/*      */     }
/* 1326 */     if ((12 < this.maxCities) && (27 < this.maxCities)) {
/* 1327 */       this.cities[12].addRoute(27, 247.5D);
/* 1328 */       this.routeCounter += 1;
/* 1329 */       this.cities[27].addRoute(12, 247.5D);
/* 1330 */       this.routeCounter += 1;
/*      */     }
/* 1332 */     if ((12 < this.maxCities) && (32 < this.maxCities)) {
/* 1333 */       this.cities[12].addRoute(32, 346.5D);
/* 1334 */       this.routeCounter += 1;
/* 1335 */       this.cities[32].addRoute(12, 346.5D);
/* 1336 */       this.routeCounter += 1;
/*      */     }
/* 1338 */     if ((13 < this.maxCities) && (14 < this.maxCities)) {
/* 1339 */       this.cities[13].addRoute(14, 198.0D);
/* 1340 */       this.routeCounter += 1;
/* 1341 */       this.cities[14].addRoute(13, 198.0D);
/* 1342 */       this.routeCounter += 1;
/*      */     }
/* 1344 */     if ((13 < this.maxCities) && (15 < this.maxCities)) {
/* 1345 */       this.cities[13].addRoute(15, 1200.0D);
/* 1346 */       this.routeCounter += 1;
/* 1347 */       this.cities[15].addRoute(13, 1200.0D);
/* 1348 */       this.routeCounter += 1;
/*      */     }
/* 1350 */     if ((13 < this.maxCities) && (16 < this.maxCities)) {
/* 1351 */       this.cities[13].addRoute(16, 1287.0D);
/* 1352 */       this.routeCounter += 1;
/* 1353 */       this.cities[16].addRoute(13, 1287.0D);
/* 1354 */       this.routeCounter += 1;
/*      */     }
/* 1356 */     if ((13 < this.maxCities) && (18 < this.maxCities)) {
/* 1357 */       this.cities[13].addRoute(18, 200.0D);
/* 1358 */       this.routeCounter += 1;
/* 1359 */       this.cities[18].addRoute(13, 200.0D);
/* 1360 */       this.routeCounter += 1;
/*      */     }
/* 1362 */     if ((13 < this.maxCities) && (19 < this.maxCities)) {
/* 1363 */       this.cities[13].addRoute(19, 1485.0D);
/* 1364 */       this.routeCounter += 1;
/* 1365 */       this.cities[19].addRoute(13, 1485.0D);
/* 1366 */       this.routeCounter += 1;
/*      */     }
/* 1368 */     if ((13 < this.maxCities) && (20 < this.maxCities)) {
/* 1369 */       this.cities[13].addRoute(20, 297.0D);
/* 1370 */       this.routeCounter += 1;
/* 1371 */       this.cities[20].addRoute(13, 297.0D);
/* 1372 */       this.routeCounter += 1;
/*      */     }
/* 1374 */     if ((13 < this.maxCities) && (21 < this.maxCities)) {
/* 1375 */       this.cities[13].addRoute(21, 940.5D);
/* 1376 */       this.routeCounter += 1;
/* 1377 */       this.cities[21].addRoute(13, 940.5D);
/* 1378 */       this.routeCounter += 1;
/*      */     }
/* 1380 */     if ((13 < this.maxCities) && (22 < this.maxCities)) {
/* 1381 */       this.cities[13].addRoute(22, 1089.0D);
/* 1382 */       this.routeCounter += 1;
/* 1383 */       this.cities[22].addRoute(13, 1089.0D);
/* 1384 */       this.routeCounter += 1;
/*      */     }
/* 1386 */     if ((13 < this.maxCities) && (23 < this.maxCities)) {
/* 1387 */       this.cities[13].addRoute(23, 198.0D);
/* 1388 */       this.routeCounter += 1;
/* 1389 */       this.cities[23].addRoute(13, 198.0D);
/* 1390 */       this.routeCounter += 1;
/*      */     }
/* 1392 */     if ((13 < this.maxCities) && (24 < this.maxCities)) {
/* 1393 */       this.cities[13].addRoute(24, 891.0D);
/* 1394 */       this.routeCounter += 1;
/* 1395 */       this.cities[24].addRoute(13, 891.0D);
/* 1396 */       this.routeCounter += 1;
/*      */     }
/* 1398 */     if ((13 < this.maxCities) && (25 < this.maxCities)) {
/* 1399 */       this.cities[13].addRoute(25, 1287.0D);
/* 1400 */       this.routeCounter += 1;
/* 1401 */       this.cities[25].addRoute(13, 1287.0D);
/* 1402 */       this.routeCounter += 1;
/*      */     }
/* 1404 */     if ((13 < this.maxCities) && (27 < this.maxCities)) {
/* 1405 */       this.cities[13].addRoute(27, 1089.0D);
/* 1406 */       this.routeCounter += 1;
/* 1407 */       this.cities[27].addRoute(13, 1089.0D);
/* 1408 */       this.routeCounter += 1;
/*      */     }
/* 1410 */     if ((13 < this.maxCities) && (28 < this.maxCities)) {
/* 1411 */       this.cities[13].addRoute(28, 247.5D);
/* 1412 */       this.routeCounter += 1;
/* 1413 */       this.cities[28].addRoute(13, 247.5D);
/* 1414 */       this.routeCounter += 1;
/*      */     }
/* 1416 */     if ((13 < this.maxCities) && (30 < this.maxCities)) {
/* 1417 */       this.cities[13].addRoute(30, 1000.0D);
/* 1418 */       this.routeCounter += 1;
/* 1419 */       this.cities[30].addRoute(13, 1000.0D);
/* 1420 */       this.routeCounter += 1;
/*      */     }
/* 1422 */     if ((13 < this.maxCities) && (31 < this.maxCities)) {
/* 1423 */       this.cities[13].addRoute(31, 792.0D);
/* 1424 */       this.routeCounter += 1;
/* 1425 */       this.cities[31].addRoute(13, 792.0D);
/* 1426 */       this.routeCounter += 1;
/*      */     }
/* 1428 */     if ((13 < this.maxCities) && (32 < this.maxCities)) {
/* 1429 */       this.cities[13].addRoute(32, 594.0D);
/* 1430 */       this.routeCounter += 1;
/* 1431 */       this.cities[32].addRoute(13, 594.0D);
/* 1432 */       this.routeCounter += 1;
/*      */     }
/* 1434 */     if ((13 < this.maxCities) && (33 < this.maxCities)) {
/* 1435 */       this.cities[13].addRoute(33, 198.0D);
/* 1436 */       this.routeCounter += 1;
/* 1437 */       this.cities[33].addRoute(13, 198.0D);
/* 1438 */       this.routeCounter += 1;
/*      */     }
/* 1440 */     if ((13 < this.maxCities) && (34 < this.maxCities)) {
/* 1441 */       this.cities[13].addRoute(34, 250.0D);
/* 1442 */       this.routeCounter += 1;
/* 1443 */       this.cities[34].addRoute(13, 250.0D);
/* 1444 */       this.routeCounter += 1;
/*      */     }
/* 1446 */     if ((13 < this.maxCities) && (35 < this.maxCities)) {
/* 1447 */       this.cities[13].addRoute(35, 148.5D);
/* 1448 */       this.routeCounter += 1;
/* 1449 */       this.cities[35].addRoute(13, 148.5D);
/* 1450 */       this.routeCounter += 1;
/*      */     }
/* 1452 */     if ((13 < this.maxCities) && (37 < this.maxCities)) {
/* 1453 */       this.cities[13].addRoute(37, 750.0D);
/* 1454 */       this.routeCounter += 1;
/* 1455 */       this.cities[37].addRoute(13, 750.0D);
/* 1456 */       this.routeCounter += 1;
/*      */     }
/* 1458 */     if ((13 < this.maxCities) && (38 < this.maxCities)) {
/* 1459 */       this.cities[13].addRoute(38, 247.5D);
/* 1460 */       this.routeCounter += 1;
/* 1461 */       this.cities[38].addRoute(13, 247.5D);
/* 1462 */       this.routeCounter += 1;
/*      */     }
/* 1464 */     if ((13 < this.maxCities) && (40 < this.maxCities)) {
/* 1465 */       this.cities[13].addRoute(40, 1108.8D);
/* 1466 */       this.routeCounter += 1;
/* 1467 */       this.cities[40].addRoute(13, 1108.8D);
/* 1468 */       this.routeCounter += 1;
/*      */     }
/* 1470 */     if ((13 < this.maxCities) && (41 < this.maxCities)) {
/* 1471 */       this.cities[13].addRoute(41, 1039.5D);
/* 1472 */       this.routeCounter += 1;
/* 1473 */       this.cities[41].addRoute(13, 1039.5D);
/* 1474 */       this.routeCounter += 1;
/*      */     }
/* 1476 */     if ((13 < this.maxCities) && (42 < this.maxCities)) {
/* 1477 */       this.cities[13].addRoute(42, 1108.8D);
/* 1478 */       this.routeCounter += 1;
/* 1479 */       this.cities[42].addRoute(13, 1108.8D);
/* 1480 */       this.routeCounter += 1;
/*      */     }
/* 1482 */     if ((13 < this.maxCities) && (44 < this.maxCities)) {
/* 1483 */       this.cities[13].addRoute(44, 297.0D);
/* 1484 */       this.routeCounter += 1;
/* 1485 */       this.cities[44].addRoute(13, 297.0D);
/* 1486 */       this.routeCounter += 1;
/*      */     }
/* 1488 */     if ((13 < this.maxCities) && (45 < this.maxCities)) {
/* 1489 */       this.cities[13].addRoute(45, 1138.5D);
/* 1490 */       this.routeCounter += 1;
/* 1491 */       this.cities[45].addRoute(13, 1138.5D);
/* 1492 */       this.routeCounter += 1;
/*      */     }
/* 1494 */     if ((13 < this.maxCities) && (47 < this.maxCities)) {
/* 1495 */       this.cities[13].addRoute(47, 841.5D);
/* 1496 */       this.routeCounter += 1;
/* 1497 */       this.cities[47].addRoute(13, 841.5D);
/* 1498 */       this.routeCounter += 1;
/*      */     }
/* 1500 */     if ((13 < this.maxCities) && (48 < this.maxCities)) {
/* 1501 */       this.cities[13].addRoute(48, 247.5D);
/* 1502 */       this.routeCounter += 1;
/* 1503 */       this.cities[48].addRoute(13, 247.5D);
/* 1504 */       this.routeCounter += 1;
/*      */     }
/* 1506 */     if ((13 < this.maxCities) && (49 < this.maxCities)) {
/* 1507 */       this.cities[13].addRoute(49, 198.0D);
/* 1508 */       this.routeCounter += 1;
/* 1509 */       this.cities[49].addRoute(13, 198.0D);
/* 1510 */       this.routeCounter += 1;
/*      */     }
/* 1512 */     if ((13 < this.maxCities) && (50 < this.maxCities)) {
/* 1513 */       this.cities[13].addRoute(50, 180.0D);
/* 1514 */       this.routeCounter += 1;
/* 1515 */       this.cities[50].addRoute(13, 180.0D);
/* 1516 */       this.routeCounter += 1;
/*      */     }
/* 1518 */     if ((14 < this.maxCities) && (16 < this.maxCities)) {
/* 1519 */       this.cities[14].addRoute(16, 1200.0D);
/* 1520 */       this.routeCounter += 1;
/* 1521 */       this.cities[16].addRoute(14, 1200.0D);
/* 1522 */       this.routeCounter += 1;
/*      */     }
/* 1524 */     if ((14 < this.maxCities) && (20 < this.maxCities)) {
/* 1525 */       this.cities[14].addRoute(20, 450.0D);
/* 1526 */       this.routeCounter += 1;
/* 1527 */       this.cities[20].addRoute(14, 450.0D);
/* 1528 */       this.routeCounter += 1;
/*      */     }
/* 1530 */     if ((14 < this.maxCities) && (23 < this.maxCities)) {
/* 1531 */       this.cities[14].addRoute(23, 450.0D);
/* 1532 */       this.routeCounter += 1;
/* 1533 */       this.cities[23].addRoute(14, 450.0D);
/* 1534 */       this.routeCounter += 1;
/*      */     }
/* 1536 */     if ((14 < this.maxCities) && (28 < this.maxCities)) {
/* 1537 */       this.cities[14].addRoute(28, 120.0D);
/* 1538 */       this.routeCounter += 1;
/* 1539 */       this.cities[28].addRoute(14, 120.0D);
/* 1540 */       this.routeCounter += 1;
/*      */     }
/* 1542 */     if ((14 < this.maxCities) && (32 < this.maxCities)) {
/* 1543 */       this.cities[14].addRoute(32, 800.0D);
/* 1544 */       this.routeCounter += 1;
/* 1545 */       this.cities[32].addRoute(14, 800.0D);
/* 1546 */       this.routeCounter += 1;
/*      */     }
/* 1548 */     if ((14 < this.maxCities) && (34 < this.maxCities)) {
/* 1549 */       this.cities[14].addRoute(34, 300.0D);
/* 1550 */       this.routeCounter += 1;
/* 1551 */       this.cities[34].addRoute(14, 300.0D);
/* 1552 */       this.routeCounter += 1;
/*      */     }
/* 1554 */     if ((14 < this.maxCities) && (35 < this.maxCities)) {
/* 1555 */       this.cities[14].addRoute(35, 99.0D);
/* 1556 */       this.routeCounter += 1;
/* 1557 */       this.cities[35].addRoute(14, 99.0D);
/* 1558 */       this.routeCounter += 1;
/*      */     }
/* 1560 */     if ((14 < this.maxCities) && (37 < this.maxCities)) {
/* 1561 */       this.cities[14].addRoute(37, 1000.0D);
/* 1562 */       this.routeCounter += 1;
/* 1563 */       this.cities[37].addRoute(14, 1000.0D);
/* 1564 */       this.routeCounter += 1;
/*      */     }
/* 1566 */     if ((14 < this.maxCities) && (38 < this.maxCities)) {
/* 1567 */       this.cities[14].addRoute(38, 100.0D);
/* 1568 */       this.routeCounter += 1;
/* 1569 */       this.cities[38].addRoute(14, 100.0D);
/* 1570 */       this.routeCounter += 1;
/*      */     }
/* 1572 */     if ((14 < this.maxCities) && (49 < this.maxCities)) {
/* 1573 */       this.cities[14].addRoute(49, 100.0D);
/* 1574 */       this.routeCounter += 1;
/* 1575 */       this.cities[49].addRoute(14, 100.0D);
/* 1576 */       this.routeCounter += 1;
/*      */     }
/* 1578 */     if ((15 < this.maxCities) && (16 < this.maxCities)) {
/* 1579 */       this.cities[15].addRoute(16, 49.5D);
/* 1580 */       this.routeCounter += 1;
/* 1581 */       this.cities[16].addRoute(15, 49.5D);
/* 1582 */       this.routeCounter += 1;
/*      */     }
/* 1584 */     if ((15 < this.maxCities) && (19 < this.maxCities)) {
/* 1585 */       this.cities[15].addRoute(19, 247.5D);
/* 1586 */       this.routeCounter += 1;
/* 1587 */       this.cities[19].addRoute(15, 247.5D);
/* 1588 */       this.routeCounter += 1;
/*      */     }
/* 1590 */     if ((15 < this.maxCities) && (22 < this.maxCities)) {
/* 1591 */       this.cities[15].addRoute(22, 247.5D);
/* 1592 */       this.routeCounter += 1;
/* 1593 */       this.cities[22].addRoute(15, 247.5D);
/* 1594 */       this.routeCounter += 1;
/*      */     }
/* 1596 */     if ((15 < this.maxCities) && (23 < this.maxCities)) {
/* 1597 */       this.cities[15].addRoute(23, 792.0D);
/* 1598 */       this.routeCounter += 1;
/* 1599 */       this.cities[23].addRoute(15, 792.0D);
/* 1600 */       this.routeCounter += 1;
/*      */     }
/* 1602 */     if ((15 < this.maxCities) && (25 < this.maxCities)) {
/* 1603 */       this.cities[15].addRoute(25, 396.0D);
/* 1604 */       this.routeCounter += 1;
/* 1605 */       this.cities[25].addRoute(15, 396.0D);
/* 1606 */       this.routeCounter += 1;
/*      */     }
/* 1608 */     if ((15 < this.maxCities) && (26 < this.maxCities)) {
/* 1609 */       this.cities[15].addRoute(26, 792.0D);
/* 1610 */       this.routeCounter += 1;
/* 1611 */       this.cities[26].addRoute(15, 792.0D);
/* 1612 */       this.routeCounter += 1;
/*      */     }
/* 1614 */     if ((15 < this.maxCities) && (35 < this.maxCities)) {
/* 1615 */       this.cities[15].addRoute(35, 792.0D);
/* 1616 */       this.routeCounter += 1;
/* 1617 */       this.cities[35].addRoute(15, 792.0D);
/* 1618 */       this.routeCounter += 1;
/*      */     }
/* 1620 */     if ((15 < this.maxCities) && (36 < this.maxCities)) {
/* 1621 */       this.cities[15].addRoute(36, 693.0D);
/* 1622 */       this.routeCounter += 1;
/* 1623 */       this.cities[36].addRoute(15, 693.0D);
/* 1624 */       this.routeCounter += 1;
/*      */     }
/* 1626 */     if ((15 < this.maxCities) && (42 < this.maxCities)) {
/* 1627 */       this.cities[15].addRoute(42, 297.0D);
/* 1628 */       this.routeCounter += 1;
/* 1629 */       this.cities[42].addRoute(15, 297.0D);
/* 1630 */       this.routeCounter += 1;
/*      */     }
/* 1632 */     if ((15 < this.maxCities) && (43 < this.maxCities)) {
/* 1633 */       this.cities[15].addRoute(43, 850.0D);
/* 1634 */       this.routeCounter += 1;
/* 1635 */       this.cities[43].addRoute(15, 850.0D);
/* 1636 */       this.routeCounter += 1;
/*      */     }
/* 1638 */     if ((15 < this.maxCities) && (50 < this.maxCities)) {
/* 1639 */       this.cities[15].addRoute(50, 1300.0D);
/* 1640 */       this.routeCounter += 1;
/* 1641 */       this.cities[50].addRoute(15, 1300.0D);
/* 1642 */       this.routeCounter += 1;
/*      */     }
/* 1644 */     if ((16 < this.maxCities) && (17 < this.maxCities)) {
/* 1645 */       this.cities[16].addRoute(17, 1000.0D);
/* 1646 */       this.routeCounter += 1;
/* 1647 */       this.cities[17].addRoute(16, 1000.0D);
/* 1648 */       this.routeCounter += 1;
/*      */     }
/* 1650 */     if ((16 < this.maxCities) && (18 < this.maxCities)) {
/* 1651 */       this.cities[16].addRoute(18, 850.0D);
/* 1652 */       this.routeCounter += 1;
/* 1653 */       this.cities[18].addRoute(16, 850.0D);
/* 1654 */       this.routeCounter += 1;
/*      */     }
/* 1656 */     if ((16 < this.maxCities) && (19 < this.maxCities)) {
/* 1657 */       this.cities[16].addRoute(19, 198.0D);
/* 1658 */       this.routeCounter += 1;
/* 1659 */       this.cities[19].addRoute(16, 198.0D);
/* 1660 */       this.routeCounter += 1;
/*      */     }
/* 1662 */     if ((16 < this.maxCities) && (22 < this.maxCities)) {
/* 1663 */       this.cities[16].addRoute(22, 250.0D);
/* 1664 */       this.routeCounter += 1;
/* 1665 */       this.cities[22].addRoute(16, 250.0D);
/* 1666 */       this.routeCounter += 1;
/*      */     }
/* 1668 */     if ((16 < this.maxCities) && (23 < this.maxCities)) {
/* 1669 */       this.cities[16].addRoute(23, 750.0D);
/* 1670 */       this.routeCounter += 1;
/* 1671 */       this.cities[23].addRoute(16, 750.0D);
/* 1672 */       this.routeCounter += 1;
/*      */     }
/* 1674 */     if ((16 < this.maxCities) && (25 < this.maxCities)) {
/* 1675 */       this.cities[16].addRoute(25, 247.5D);
/* 1676 */       this.routeCounter += 1;
/* 1677 */       this.cities[25].addRoute(16, 247.5D);
/* 1678 */       this.routeCounter += 1;
/*      */     }
/* 1680 */     if ((16 < this.maxCities) && (26 < this.maxCities)) {
/* 1681 */       this.cities[16].addRoute(26, 811.79999999999995D);
/* 1682 */       this.routeCounter += 1;
/* 1683 */       this.cities[26].addRoute(16, 811.79999999999995D);
/* 1684 */       this.routeCounter += 1;
/*      */     }
/* 1686 */     if ((16 < this.maxCities) && (35 < this.maxCities)) {
/* 1687 */       this.cities[16].addRoute(35, 811.79999999999995D);
/* 1688 */       this.routeCounter += 1;
/* 1689 */       this.cities[35].addRoute(16, 811.79999999999995D);
/* 1690 */       this.routeCounter += 1;
/*      */     }
/* 1692 */     if ((16 < this.maxCities) && (36 < this.maxCities)) {
/* 1693 */       this.cities[16].addRoute(36, 712.79999999999995D);
/* 1694 */       this.routeCounter += 1;
/* 1695 */       this.cities[36].addRoute(16, 712.79999999999995D);
/* 1696 */       this.routeCounter += 1;
/*      */     }
/* 1698 */     if ((16 < this.maxCities) && (38 < this.maxCities)) {
/* 1699 */       this.cities[16].addRoute(38, 800.0D);
/* 1700 */       this.routeCounter += 1;
/* 1701 */       this.cities[38].addRoute(16, 800.0D);
/* 1702 */       this.routeCounter += 1;
/*      */     }
/* 1704 */     if ((16 < this.maxCities) && (40 < this.maxCities)) {
/* 1705 */       this.cities[16].addRoute(40, 396.0D);
/* 1706 */       this.routeCounter += 1;
/* 1707 */       this.cities[40].addRoute(16, 396.0D);
/* 1708 */       this.routeCounter += 1;
/*      */     }
/* 1710 */     if ((16 < this.maxCities) && (41 < this.maxCities)) {
/* 1711 */       this.cities[16].addRoute(41, 148.5D);
/* 1712 */       this.routeCounter += 1;
/* 1713 */       this.cities[41].addRoute(16, 148.5D);
/* 1714 */       this.routeCounter += 1;
/*      */     }
/* 1716 */     if ((16 < this.maxCities) && (42 < this.maxCities)) {
/* 1717 */       this.cities[16].addRoute(42, 356.39999999999998D);
/* 1718 */       this.routeCounter += 1;
/* 1719 */       this.cities[42].addRoute(16, 356.39999999999998D);
/* 1720 */       this.routeCounter += 1;
/*      */     }
/* 1722 */     if ((16 < this.maxCities) && (43 < this.maxCities)) {
/* 1723 */       this.cities[16].addRoute(43, 890.0D);
/* 1724 */       this.routeCounter += 1;
/* 1725 */       this.cities[43].addRoute(16, 890.0D);
/* 1726 */       this.routeCounter += 1;
/*      */     }
/* 1728 */     if ((16 < this.maxCities) && (45 < this.maxCities)) {
/* 1729 */       this.cities[16].addRoute(45, 420.0D);
/* 1730 */       this.routeCounter += 1;
/* 1731 */       this.cities[45].addRoute(16, 420.0D);
/* 1732 */       this.routeCounter += 1;
/*      */     }
/* 1734 */     if ((16 < this.maxCities) && (46 < this.maxCities)) {
/* 1735 */       this.cities[16].addRoute(46, 663.29999999999995D);
/* 1736 */       this.routeCounter += 1;
/* 1737 */       this.cities[46].addRoute(16, 663.29999999999995D);
/* 1738 */       this.routeCounter += 1;
/*      */     }
/* 1740 */     if ((16 < this.maxCities) && (47 < this.maxCities)) {
/* 1741 */       this.cities[16].addRoute(47, 1188.0D);
/* 1742 */       this.routeCounter += 1;
/* 1743 */       this.cities[47].addRoute(16, 1188.0D);
/* 1744 */       this.routeCounter += 1;
/*      */     }
/* 1746 */     if ((16 < this.maxCities) && (49 < this.maxCities)) {
/* 1747 */       this.cities[16].addRoute(49, 990.0D);
/* 1748 */       this.routeCounter += 1;
/* 1749 */       this.cities[49].addRoute(16, 990.0D);
/* 1750 */       this.routeCounter += 1;
/*      */     }
/* 1752 */     if ((16 < this.maxCities) && (50 < this.maxCities)) {
/* 1753 */       this.cities[16].addRoute(50, 1290.0D);
/* 1754 */       this.routeCounter += 1;
/* 1755 */       this.cities[50].addRoute(16, 1290.0D);
/* 1756 */       this.routeCounter += 1;
/*      */     }
/* 1758 */     if ((17 < this.maxCities) && (24 < this.maxCities)) {
/* 1759 */       this.cities[17].addRoute(24, 600.0D);
/* 1760 */       this.routeCounter += 1;
/* 1761 */       this.cities[24].addRoute(17, 600.0D);
/* 1762 */       this.routeCounter += 1;
/*      */     }
/* 1764 */     if ((17 < this.maxCities) && (27 < this.maxCities)) {
/* 1765 */       this.cities[17].addRoute(27, 643.5D);
/* 1766 */       this.routeCounter += 1;
/* 1767 */       this.cities[27].addRoute(17, 643.5D);
/* 1768 */       this.routeCounter += 1;
/*      */     }
/* 1770 */     if ((17 < this.maxCities) && (32 < this.maxCities)) {
/* 1771 */       this.cities[17].addRoute(32, 990.0D);
/* 1772 */       this.routeCounter += 1;
/* 1773 */       this.cities[32].addRoute(17, 990.0D);
/* 1774 */       this.routeCounter += 1;
/*      */     }
/* 1776 */     if ((17 < this.maxCities) && (40 < this.maxCities)) {
/* 1777 */       this.cities[17].addRoute(40, 792.0D);
/* 1778 */       this.routeCounter += 1;
/* 1779 */       this.cities[40].addRoute(17, 792.0D);
/* 1780 */       this.routeCounter += 1;
/*      */     }
/* 1782 */     if ((17 < this.maxCities) && (43 < this.maxCities)) {
/* 1783 */       this.cities[17].addRoute(43, 950.0D);
/* 1784 */       this.routeCounter += 1;
/* 1785 */       this.cities[43].addRoute(17, 950.0D);
/* 1786 */       this.routeCounter += 1;
/*      */     }
/* 1788 */     if ((17 < this.maxCities) && (45 < this.maxCities)) {
/* 1789 */       this.cities[17].addRoute(45, 750.0D);
/* 1790 */       this.routeCounter += 1;
/* 1791 */       this.cities[45].addRoute(17, 750.0D);
/* 1792 */       this.routeCounter += 1;
/*      */     }
/* 1794 */     if ((17 < this.maxCities) && (47 < this.maxCities)) {
/* 1795 */       this.cities[17].addRoute(47, 841.5D);
/* 1796 */       this.routeCounter += 1;
/* 1797 */       this.cities[47].addRoute(17, 841.5D);
/* 1798 */       this.routeCounter += 1;
/*      */     }
/* 1800 */     if ((18 < this.maxCities) && (23 < this.maxCities)) {
/* 1801 */       this.cities[18].addRoute(23, 445.5D);
/* 1802 */       this.routeCounter += 1;
/* 1803 */       this.cities[23].addRoute(18, 445.5D);
/* 1804 */       this.routeCounter += 1;
/*      */     }
/* 1806 */     if ((18 < this.maxCities) && (28 < this.maxCities)) {
/* 1807 */       this.cities[18].addRoute(28, 297.0D);
/* 1808 */       this.routeCounter += 1;
/* 1809 */       this.cities[28].addRoute(18, 297.0D);
/* 1810 */       this.routeCounter += 1;
/*      */     }
/* 1812 */     if ((18 < this.maxCities) && (30 < this.maxCities)) {
/* 1813 */       this.cities[18].addRoute(30, 650.0D);
/* 1814 */       this.routeCounter += 1;
/* 1815 */       this.cities[30].addRoute(18, 650.0D);
/* 1816 */       this.routeCounter += 1;
/*      */     }
/* 1818 */     if ((18 < this.maxCities) && (32 < this.maxCities)) {
/* 1819 */       this.cities[18].addRoute(32, 970.20000000000005D);
/* 1820 */       this.routeCounter += 1;
/* 1821 */       this.cities[32].addRoute(18, 970.20000000000005D);
/* 1822 */       this.routeCounter += 1;
/*      */     }
/* 1824 */     if ((18 < this.maxCities) && (34 < this.maxCities)) {
/* 1825 */       this.cities[18].addRoute(34, 550.0D);
/* 1826 */       this.routeCounter += 1;
/* 1827 */       this.cities[34].addRoute(18, 550.0D);
/* 1828 */       this.routeCounter += 1;
/*      */     }
/* 1830 */     if ((18 < this.maxCities) && (35 < this.maxCities)) {
/* 1831 */       this.cities[18].addRoute(35, 346.5D);
/* 1832 */       this.routeCounter += 1;
/* 1833 */       this.cities[35].addRoute(18, 346.5D);
/* 1834 */       this.routeCounter += 1;
/*      */     }
/* 1836 */     if ((18 < this.maxCities) && (38 < this.maxCities)) {
/* 1837 */       this.cities[18].addRoute(38, 277.19999999999999D);
/* 1838 */       this.routeCounter += 1;
/* 1839 */       this.cities[38].addRoute(18, 277.19999999999999D);
/* 1840 */       this.routeCounter += 1;
/*      */     }
/* 1842 */     if ((18 < this.maxCities) && (42 < this.maxCities)) {
/* 1843 */       this.cities[18].addRoute(42, 762.29999999999995D);
/* 1844 */       this.routeCounter += 1;
/* 1845 */       this.cities[42].addRoute(18, 762.29999999999995D);
/* 1846 */       this.routeCounter += 1;
/*      */     }
/* 1848 */     if ((18 < this.maxCities) && (44 < this.maxCities)) {
/* 1849 */       this.cities[18].addRoute(44, 465.30000000000001D);
/* 1850 */       this.routeCounter += 1;
/* 1851 */       this.cities[44].addRoute(18, 465.30000000000001D);
/* 1852 */       this.routeCounter += 1;
/*      */     }
/* 1854 */     if ((18 < this.maxCities) && (49 < this.maxCities)) {
/* 1855 */       this.cities[18].addRoute(49, 247.5D);
/* 1856 */       this.routeCounter += 1;
/* 1857 */       this.cities[49].addRoute(18, 247.5D);
/* 1858 */       this.routeCounter += 1;
/*      */     }
/* 1860 */     if ((18 < this.maxCities) && (50 < this.maxCities)) {
/* 1861 */       this.cities[18].addRoute(50, 300.0D);
/* 1862 */       this.routeCounter += 1;
/* 1863 */       this.cities[50].addRoute(18, 300.0D);
/* 1864 */       this.routeCounter += 1;
/*      */     }
/* 1866 */     if ((19 < this.maxCities) && (22 < this.maxCities)) {
/* 1867 */       this.cities[19].addRoute(22, 250.0D);
/* 1868 */       this.routeCounter += 1;
/* 1869 */       this.cities[22].addRoute(19, 250.0D);
/* 1870 */       this.routeCounter += 1;
/*      */     }
/* 1872 */     if ((19 < this.maxCities) && (23 < this.maxCities)) {
/* 1873 */       this.cities[19].addRoute(23, 1080.0D);
/* 1874 */       this.routeCounter += 1;
/* 1875 */       this.cities[23].addRoute(19, 1080.0D);
/* 1876 */       this.routeCounter += 1;
/*      */     }
/* 1878 */     if ((19 < this.maxCities) && (26 < this.maxCities)) {
/* 1879 */       this.cities[19].addRoute(26, 700.0D);
/* 1880 */       this.routeCounter += 1;
/* 1881 */       this.cities[26].addRoute(19, 700.0D);
/* 1882 */       this.routeCounter += 1;
/*      */     }
/* 1884 */     if ((19 < this.maxCities) && (30 < this.maxCities)) {
/* 1885 */       this.cities[19].addRoute(30, 350.0D);
/* 1886 */       this.routeCounter += 1;
/* 1887 */       this.cities[30].addRoute(19, 350.0D);
/* 1888 */       this.routeCounter += 1;
/*      */     }
/* 1890 */     if ((19 < this.maxCities) && (41 < this.maxCities)) {
/* 1891 */       this.cities[19].addRoute(41, 380.0D);
/* 1892 */       this.routeCounter += 1;
/* 1893 */       this.cities[41].addRoute(19, 380.0D);
/* 1894 */       this.routeCounter += 1;
/*      */     }
/* 1896 */     if ((19 < this.maxCities) && (42 < this.maxCities)) {
/* 1897 */       this.cities[19].addRoute(42, 150.0D);
/* 1898 */       this.routeCounter += 1;
/* 1899 */       this.cities[42].addRoute(19, 150.0D);
/* 1900 */       this.routeCounter += 1;
/*      */     }
/* 1902 */     if ((19 < this.maxCities) && (45 < this.maxCities)) {
/* 1903 */       this.cities[19].addRoute(45, 450.0D);
/* 1904 */       this.routeCounter += 1;
/* 1905 */       this.cities[45].addRoute(19, 450.0D);
/* 1906 */       this.routeCounter += 1;
/*      */     }
/* 1908 */     if ((20 < this.maxCities) && (21 < this.maxCities)) {
/* 1909 */       this.cities[20].addRoute(21, 850.0D);
/* 1910 */       this.routeCounter += 1;
/* 1911 */       this.cities[21].addRoute(20, 850.0D);
/* 1912 */       this.routeCounter += 1;
/*      */     }
/* 1914 */     if ((20 < this.maxCities) && (23 < this.maxCities)) {
/* 1915 */       this.cities[20].addRoute(23, 550.0D);
/* 1916 */       this.routeCounter += 1;
/* 1917 */       this.cities[23].addRoute(20, 550.0D);
/* 1918 */       this.routeCounter += 1;
/*      */     }
/* 1920 */     if ((20 < this.maxCities) && (28 < this.maxCities)) {
/* 1921 */       this.cities[20].addRoute(28, 400.0D);
/* 1922 */       this.routeCounter += 1;
/* 1923 */       this.cities[28].addRoute(20, 400.0D);
/* 1924 */       this.routeCounter += 1;
/*      */     }
/* 1926 */     if ((20 < this.maxCities) && (31 < this.maxCities)) {
/* 1927 */       this.cities[20].addRoute(31, 445.5D);
/* 1928 */       this.routeCounter += 1;
/* 1929 */       this.cities[31].addRoute(20, 445.5D);
/* 1930 */       this.routeCounter += 1;
/*      */     }
/* 1932 */     if ((20 < this.maxCities) && (32 < this.maxCities)) {
/* 1933 */       this.cities[20].addRoute(32, 1250.0D);
/* 1934 */       this.routeCounter += 1;
/* 1935 */       this.cities[32].addRoute(20, 1250.0D);
/* 1936 */       this.routeCounter += 1;
/*      */     }
/* 1938 */     if ((20 < this.maxCities) && (33 < this.maxCities)) {
/* 1939 */       this.cities[20].addRoute(33, 450.0D);
/* 1940 */       this.routeCounter += 1;
/* 1941 */       this.cities[33].addRoute(20, 450.0D);
/* 1942 */       this.routeCounter += 1;
/*      */     }
/* 1944 */     if ((20 < this.maxCities) && (34 < this.maxCities)) {
/* 1945 */       this.cities[20].addRoute(34, 600.0D);
/* 1946 */       this.routeCounter += 1;
/* 1947 */       this.cities[34].addRoute(20, 600.0D);
/* 1948 */       this.routeCounter += 1;
/*      */     }
/* 1950 */     if ((20 < this.maxCities) && (35 < this.maxCities)) {
/* 1951 */       this.cities[20].addRoute(35, 495.0D);
/* 1952 */       this.routeCounter += 1;
/* 1953 */       this.cities[35].addRoute(20, 495.0D);
/* 1954 */       this.routeCounter += 1;
/*      */     }
/* 1956 */     if ((20 < this.maxCities) && (38 < this.maxCities)) {
/* 1957 */       this.cities[20].addRoute(38, 450.0D);
/* 1958 */       this.routeCounter += 1;
/* 1959 */       this.cities[38].addRoute(20, 450.0D);
/* 1960 */       this.routeCounter += 1;
/*      */     }
/* 1962 */     if ((20 < this.maxCities) && (49 < this.maxCities)) {
/* 1963 */       this.cities[20].addRoute(49, 450.0D);
/* 1964 */       this.routeCounter += 1;
/* 1965 */       this.cities[49].addRoute(20, 450.0D);
/* 1966 */       this.routeCounter += 1;
/*      */     }
/* 1968 */     if ((20 < this.maxCities) && (50 < this.maxCities)) {
/* 1969 */       this.cities[20].addRoute(50, 450.0D);
/* 1970 */       this.routeCounter += 1;
/* 1971 */       this.cities[50].addRoute(20, 450.0D);
/* 1972 */       this.routeCounter += 1;
/*      */     }
/* 1974 */     if ((21 < this.maxCities) && (23 < this.maxCities)) {
/* 1975 */       this.cities[21].addRoute(23, 1100.0D);
/* 1976 */       this.routeCounter += 1;
/* 1977 */       this.cities[23].addRoute(21, 1100.0D);
/* 1978 */       this.routeCounter += 1;
/*      */     }
/* 1980 */     if ((21 < this.maxCities) && (31 < this.maxCities)) {
/* 1981 */       this.cities[21].addRoute(31, 554.39999999999998D);
/* 1982 */       this.routeCounter += 1;
/* 1983 */       this.cities[31].addRoute(21, 554.39999999999998D);
/* 1984 */       this.routeCounter += 1;
/*      */     }
/* 1986 */     if ((21 < this.maxCities) && (35 < this.maxCities)) {
/* 1987 */       this.cities[21].addRoute(35, 980.10000000000002D);
/* 1988 */       this.routeCounter += 1;
/* 1989 */       this.cities[35].addRoute(21, 980.10000000000002D);
/* 1990 */       this.routeCounter += 1;
/*      */     }
/* 1992 */     if ((21 < this.maxCities) && (36 < this.maxCities)) {
/* 1993 */       this.cities[21].addRoute(36, 980.10000000000002D);
/* 1994 */       this.routeCounter += 1;
/* 1995 */       this.cities[36].addRoute(21, 980.10000000000002D);
/* 1996 */       this.routeCounter += 1;
/*      */     }
/* 1998 */     if ((21 < this.maxCities) && (42 < this.maxCities)) {
/* 1999 */       this.cities[21].addRoute(42, 1188.0D);
/* 2000 */       this.routeCounter += 1;
/* 2001 */       this.cities[42].addRoute(21, 1188.0D);
/* 2002 */       this.routeCounter += 1;
/*      */     }
/* 2004 */     if ((21 < this.maxCities) && (43 < this.maxCities)) {
/* 2005 */       this.cities[21].addRoute(43, 1150.0D);
/* 2006 */       this.routeCounter += 1;
/* 2007 */       this.cities[43].addRoute(21, 1150.0D);
/* 2008 */       this.routeCounter += 1;
/*      */     }
/* 2010 */     if ((21 < this.maxCities) && (50 < this.maxCities)) {
/* 2011 */       this.cities[21].addRoute(50, 1050.0D);
/* 2012 */       this.routeCounter += 1;
/* 2013 */       this.cities[50].addRoute(21, 1050.0D);
/* 2014 */       this.routeCounter += 1;
/*      */     }
/* 2016 */     if ((22 < this.maxCities) && (23 < this.maxCities)) {
/* 2017 */       this.cities[22].addRoute(23, 1000.0D);
/* 2018 */       this.routeCounter += 1;
/* 2019 */       this.cities[23].addRoute(22, 1000.0D);
/* 2020 */       this.routeCounter += 1;
/*      */     }
/* 2022 */     if ((22 < this.maxCities) && (25 < this.maxCities)) {
/* 2023 */       this.cities[22].addRoute(25, 594.0D);
/* 2024 */       this.routeCounter += 1;
/* 2025 */       this.cities[25].addRoute(22, 594.0D);
/* 2026 */       this.routeCounter += 1;
/*      */     }
/* 2028 */     if ((22 < this.maxCities) && (30 < this.maxCities)) {
/* 2029 */       this.cities[22].addRoute(30, 200.0D);
/* 2030 */       this.routeCounter += 1;
/* 2031 */       this.cities[30].addRoute(22, 200.0D);
/* 2032 */       this.routeCounter += 1;
/*      */     }
/* 2034 */     if ((22 < this.maxCities) && (31 < this.maxCities)) {
/* 2035 */       this.cities[22].addRoute(31, 544.5D);
/* 2036 */       this.routeCounter += 1;
/* 2037 */       this.cities[31].addRoute(22, 544.5D);
/* 2038 */       this.routeCounter += 1;
/*      */     }
/* 2040 */     if ((22 < this.maxCities) && (35 < this.maxCities)) {
/* 2041 */       this.cities[22].addRoute(35, 940.5D);
/* 2042 */       this.routeCounter += 1;
/* 2043 */       this.cities[35].addRoute(22, 940.5D);
/* 2044 */       this.routeCounter += 1;
/*      */     }
/* 2046 */     if ((22 < this.maxCities) && (42 < this.maxCities)) {
/* 2047 */       this.cities[22].addRoute(42, 346.5D);
/* 2048 */       this.routeCounter += 1;
/* 2049 */       this.cities[42].addRoute(22, 346.5D);
/* 2050 */       this.routeCounter += 1;
/*      */     }
/* 2052 */     if ((23 < this.maxCities) && (24 < this.maxCities)) {
/* 2053 */       this.cities[23].addRoute(24, 1100.0D);
/* 2054 */       this.routeCounter += 1;
/* 2055 */       this.cities[24].addRoute(23, 1100.0D);
/* 2056 */       this.routeCounter += 1;
/*      */     }
/* 2058 */     if ((23 < this.maxCities) && (25 < this.maxCities)) {
/* 2059 */       this.cities[23].addRoute(25, 1188.0D);
/* 2060 */       this.routeCounter += 1;
/* 2061 */       this.cities[25].addRoute(23, 1188.0D);
/* 2062 */       this.routeCounter += 1;
/*      */     }
/* 2064 */     if ((23 < this.maxCities) && (27 < this.maxCities)) {
/* 2065 */       this.cities[23].addRoute(27, 891.0D);
/* 2066 */       this.routeCounter += 1;
/* 2067 */       this.cities[27].addRoute(23, 891.0D);
/* 2068 */       this.routeCounter += 1;
/*      */     }
/* 2070 */     if ((23 < this.maxCities) && (28 < this.maxCities)) {
/* 2071 */       this.cities[23].addRoute(28, 297.0D);
/* 2072 */       this.routeCounter += 1;
/* 2073 */       this.cities[28].addRoute(23, 297.0D);
/* 2074 */       this.routeCounter += 1;
/*      */     }
/* 2076 */     if ((23 < this.maxCities) && (30 < this.maxCities)) {
/* 2077 */       this.cities[23].addRoute(30, 800.0D);
/* 2078 */       this.routeCounter += 1;
/* 2079 */       this.cities[30].addRoute(23, 800.0D);
/* 2080 */       this.routeCounter += 1;
/*      */     }
/* 2082 */     if ((23 < this.maxCities) && (31 < this.maxCities)) {
/* 2083 */       this.cities[23].addRoute(31, 643.5D);
/* 2084 */       this.routeCounter += 1;
/* 2085 */       this.cities[31].addRoute(23, 643.5D);
/* 2086 */       this.routeCounter += 1;
/*      */     }
/* 2088 */     if ((23 < this.maxCities) && (32 < this.maxCities)) {
/* 2089 */       this.cities[23].addRoute(32, 594.0D);
/* 2090 */       this.routeCounter += 1;
/* 2091 */       this.cities[32].addRoute(23, 594.0D);
/* 2092 */       this.routeCounter += 1;
/*      */     }
/* 2094 */     if ((23 < this.maxCities) && (33 < this.maxCities)) {
/* 2095 */       this.cities[23].addRoute(33, 247.5D);
/* 2096 */       this.routeCounter += 1;
/* 2097 */       this.cities[33].addRoute(23, 247.5D);
/* 2098 */       this.routeCounter += 1;
/*      */     }
/* 2100 */     if ((23 < this.maxCities) && (34 < this.maxCities)) {
/* 2101 */       this.cities[23].addRoute(34, 200.0D);
/* 2102 */       this.routeCounter += 1;
/* 2103 */       this.cities[34].addRoute(23, 200.0D);
/* 2104 */       this.routeCounter += 1;
/*      */     }
/* 2106 */     if ((23 < this.maxCities) && (35 < this.maxCities)) {
/* 2107 */       this.cities[23].addRoute(35, 148.5D);
/* 2108 */       this.routeCounter += 1;
/* 2109 */       this.cities[35].addRoute(23, 148.5D);
/* 2110 */       this.routeCounter += 1;
/*      */     }
/* 2112 */     if ((23 < this.maxCities) && (37 < this.maxCities)) {
/* 2113 */       this.cities[23].addRoute(37, 700.0D);
/* 2114 */       this.routeCounter += 1;
/* 2115 */       this.cities[37].addRoute(23, 700.0D);
/* 2116 */       this.routeCounter += 1;
/*      */     }
/* 2118 */     if ((23 < this.maxCities) && (38 < this.maxCities)) {
/* 2119 */       this.cities[23].addRoute(38, 400.0D);
/* 2120 */       this.routeCounter += 1;
/* 2121 */       this.cities[38].addRoute(23, 400.0D);
/* 2122 */       this.routeCounter += 1;
/*      */     }
/* 2124 */     if ((23 < this.maxCities) && (39 < this.maxCities)) {
/* 2125 */       this.cities[23].addRoute(39, 1138.5D);
/* 2126 */       this.routeCounter += 1;
/* 2127 */       this.cities[39].addRoute(23, 1138.5D);
/* 2128 */       this.routeCounter += 1;
/*      */     }
/* 2130 */     if ((23 < this.maxCities) && (40 < this.maxCities)) {
/* 2131 */       this.cities[23].addRoute(40, 990.0D);
/* 2132 */       this.routeCounter += 1;
/* 2133 */       this.cities[40].addRoute(23, 990.0D);
/* 2134 */       this.routeCounter += 1;
/*      */     }
/* 2136 */     if ((23 < this.maxCities) && (41 < this.maxCities)) {
/* 2137 */       this.cities[23].addRoute(41, 980.10000000000002D);
/* 2138 */       this.routeCounter += 1;
/* 2139 */       this.cities[41].addRoute(23, 980.10000000000002D);
/* 2140 */       this.routeCounter += 1;
/*      */     }
/* 2142 */     if ((23 < this.maxCities) && (42 < this.maxCities)) {
/* 2143 */       this.cities[23].addRoute(42, 1089.0D);
/* 2144 */       this.routeCounter += 1;
/* 2145 */       this.cities[42].addRoute(23, 1089.0D);
/* 2146 */       this.routeCounter += 1;
/*      */     }
/* 2148 */     if ((23 < this.maxCities) && (44 < this.maxCities)) {
/* 2149 */       this.cities[23].addRoute(44, 445.5D);
/* 2150 */       this.routeCounter += 1;
/* 2151 */       this.cities[44].addRoute(23, 445.5D);
/* 2152 */       this.routeCounter += 1;
/*      */     }
/* 2154 */     if ((23 < this.maxCities) && (45 < this.maxCities)) {
/* 2155 */       this.cities[23].addRoute(45, 1050.0D);
/* 2156 */       this.routeCounter += 1;
/* 2157 */       this.cities[45].addRoute(23, 1050.0D);
/* 2158 */       this.routeCounter += 1;
/*      */     }
/* 2160 */     if ((23 < this.maxCities) && (47 < this.maxCities)) {
/* 2161 */       this.cities[23].addRoute(47, 940.5D);
/* 2162 */       this.routeCounter += 1;
/* 2163 */       this.cities[47].addRoute(23, 940.5D);
/* 2164 */       this.routeCounter += 1;
/*      */     }
/* 2166 */     if ((23 < this.maxCities) && (48 < this.maxCities)) {
/* 2167 */       this.cities[23].addRoute(48, 396.0D);
/* 2168 */       this.routeCounter += 1;
/* 2169 */       this.cities[48].addRoute(23, 396.0D);
/* 2170 */       this.routeCounter += 1;
/*      */     }
/* 2172 */     if ((23 < this.maxCities) && (49 < this.maxCities)) {
/* 2173 */       this.cities[23].addRoute(49, 316.80000000000001D);
/* 2174 */       this.routeCounter += 1;
/* 2175 */       this.cities[49].addRoute(23, 316.80000000000001D);
/* 2176 */       this.routeCounter += 1;
/*      */     }
/* 2178 */     if ((23 < this.maxCities) && (50 < this.maxCities)) {
/* 2179 */       this.cities[23].addRoute(50, 290.0D);
/* 2180 */       this.routeCounter += 1;
/* 2181 */       this.cities[50].addRoute(23, 290.0D);
/* 2182 */       this.routeCounter += 1;
/*      */     }
/* 2184 */     if ((24 < this.maxCities) && (25 < this.maxCities)) {
/* 2185 */       this.cities[24].addRoute(25, 792.0D);
/* 2186 */       this.routeCounter += 1;
/* 2187 */       this.cities[25].addRoute(24, 792.0D);
/* 2188 */       this.routeCounter += 1;
/*      */     }
/* 2190 */     if ((24 < this.maxCities) && (27 < this.maxCities)) {
/* 2191 */       this.cities[24].addRoute(27, 297.0D);
/* 2192 */       this.routeCounter += 1;
/* 2193 */       this.cities[27].addRoute(24, 297.0D);
/* 2194 */       this.routeCounter += 1;
/*      */     }
/* 2196 */     if ((24 < this.maxCities) && (32 < this.maxCities)) {
/* 2197 */       this.cities[24].addRoute(32, 346.5D);
/* 2198 */       this.routeCounter += 1;
/* 2199 */       this.cities[32].addRoute(24, 346.5D);
/* 2200 */       this.routeCounter += 1;
/*      */     }
/* 2202 */     if ((24 < this.maxCities) && (34 < this.maxCities)) {
/* 2203 */       this.cities[24].addRoute(34, 990.0D);
/* 2204 */       this.routeCounter += 1;
/* 2205 */       this.cities[34].addRoute(24, 990.0D);
/* 2206 */       this.routeCounter += 1;
/*      */     }
/* 2208 */     if ((24 < this.maxCities) && (40 < this.maxCities)) {
/* 2209 */       this.cities[24].addRoute(40, 891.0D);
/* 2210 */       this.routeCounter += 1;
/* 2211 */       this.cities[40].addRoute(24, 891.0D);
/* 2212 */       this.routeCounter += 1;
/*      */     }
/* 2214 */     if ((24 < this.maxCities) && (42 < this.maxCities)) {
/* 2215 */       this.cities[24].addRoute(42, 1287.0D);
/* 2216 */       this.routeCounter += 1;
/* 2217 */       this.cities[42].addRoute(24, 1287.0D);
/* 2218 */       this.routeCounter += 1;
/*      */     }
/* 2220 */     if ((24 < this.maxCities) && (43 < this.maxCities)) {
/* 2221 */       this.cities[24].addRoute(43, 1300.0D);
/* 2222 */       this.routeCounter += 1;
/* 2223 */       this.cities[43].addRoute(24, 1300.0D);
/* 2224 */       this.routeCounter += 1;
/*      */     }
/* 2226 */     if ((24 < this.maxCities) && (45 < this.maxCities)) {
/* 2227 */       this.cities[24].addRoute(45, 1000.0D);
/* 2228 */       this.routeCounter += 1;
/* 2229 */       this.cities[45].addRoute(24, 1000.0D);
/* 2230 */       this.routeCounter += 1;
/*      */     }
/* 2232 */     if ((24 < this.maxCities) && (50 < this.maxCities)) {
/* 2233 */       this.cities[24].addRoute(50, 1080.0D);
/* 2234 */       this.routeCounter += 1;
/* 2235 */       this.cities[50].addRoute(24, 1080.0D);
/* 2236 */       this.routeCounter += 1;
/*      */     }
/* 2238 */     if ((25 < this.maxCities) && (41 < this.maxCities)) {
/* 2239 */       this.cities[25].addRoute(41, 200.0D);
/* 2240 */       this.routeCounter += 1;
/* 2241 */       this.cities[41].addRoute(25, 200.0D);
/* 2242 */       this.routeCounter += 1;
/*      */     }
/* 2244 */     if ((25 < this.maxCities) && (45 < this.maxCities)) {
/* 2245 */       this.cities[25].addRoute(45, 300.0D);
/* 2246 */       this.routeCounter += 1;
/* 2247 */       this.cities[45].addRoute(25, 300.0D);
/* 2248 */       this.routeCounter += 1;
/*      */     }
/* 2250 */     if ((26 < this.maxCities) && (36 < this.maxCities)) {
/* 2251 */       this.cities[26].addRoute(36, 500.0D);
/* 2252 */       this.routeCounter += 1;
/* 2253 */       this.cities[36].addRoute(26, 500.0D);
/* 2254 */       this.routeCounter += 1;
/*      */     }
/* 2256 */     if ((26 < this.maxCities) && (41 < this.maxCities)) {
/* 2257 */       this.cities[26].addRoute(41, 800.0D);
/* 2258 */       this.routeCounter += 1;
/* 2259 */       this.cities[41].addRoute(26, 800.0D);
/* 2260 */       this.routeCounter += 1;
/*      */     }
/* 2262 */     if ((26 < this.maxCities) && (43 < this.maxCities)) {
/* 2263 */       this.cities[26].addRoute(43, 200.0D);
/* 2264 */       this.routeCounter += 1;
/* 2265 */       this.cities[43].addRoute(26, 200.0D);
/* 2266 */       this.routeCounter += 1;
/*      */     }
/* 2268 */     if ((26 < this.maxCities) && (45 < this.maxCities)) {
/* 2269 */       this.cities[26].addRoute(45, 900.0D);
/* 2270 */       this.routeCounter += 1;
/* 2271 */       this.cities[45].addRoute(26, 900.0D);
/* 2272 */       this.routeCounter += 1;
/*      */     }
/* 2274 */     if ((27 < this.maxCities) && (32 < this.maxCities)) {
/* 2275 */       this.cities[27].addRoute(32, 600.0D);
/* 2276 */       this.routeCounter += 1;
/* 2277 */       this.cities[32].addRoute(27, 600.0D);
/* 2278 */       this.routeCounter += 1;
/*      */     }
/* 2280 */     if ((27 < this.maxCities) && (39 < this.maxCities)) {
/* 2281 */       this.cities[27].addRoute(39, 643.5D);
/* 2282 */       this.routeCounter += 1;
/* 2283 */       this.cities[39].addRoute(27, 643.5D);
/* 2284 */       this.routeCounter += 1;
/*      */     }
/* 2286 */     if ((27 < this.maxCities) && (47 < this.maxCities)) {
/* 2287 */       this.cities[27].addRoute(47, 940.5D);
/* 2288 */       this.routeCounter += 1;
/* 2289 */       this.cities[47].addRoute(27, 940.5D);
/* 2290 */       this.routeCounter += 1;
/*      */     }
/* 2292 */     if ((27 < this.maxCities) && (50 < this.maxCities)) {
/* 2293 */       this.cities[27].addRoute(50, 1020.0D);
/* 2294 */       this.routeCounter += 1;
/* 2295 */       this.cities[50].addRoute(27, 1020.0D);
/* 2296 */       this.routeCounter += 1;
/*      */     }
/* 2298 */     if ((28 < this.maxCities) && (32 < this.maxCities)) {
/* 2299 */       this.cities[28].addRoute(32, 940.5D);
/* 2300 */       this.routeCounter += 1;
/* 2301 */       this.cities[32].addRoute(28, 940.5D);
/* 2302 */       this.routeCounter += 1;
/*      */     }
/* 2304 */     if ((28 < this.maxCities) && (33 < this.maxCities)) {
/* 2305 */       this.cities[28].addRoute(33, 200.0D);
/* 2306 */       this.routeCounter += 1;
/* 2307 */       this.cities[33].addRoute(28, 200.0D);
/* 2308 */       this.routeCounter += 1;
/*      */     }
/* 2310 */     if ((28 < this.maxCities) && (34 < this.maxCities)) {
/* 2311 */       this.cities[28].addRoute(34, 450.0D);
/* 2312 */       this.routeCounter += 1;
/* 2313 */       this.cities[34].addRoute(28, 450.0D);
/* 2314 */       this.routeCounter += 1;
/*      */     }
/* 2316 */     if ((28 < this.maxCities) && (48 < this.maxCities)) {
/* 2317 */       this.cities[28].addRoute(48, 69.299999999999997D);
/* 2318 */       this.routeCounter += 1;
/* 2319 */       this.cities[48].addRoute(28, 69.299999999999997D);
/* 2320 */       this.routeCounter += 1;
/*      */     }
/* 2322 */     if ((28 < this.maxCities) && (50 < this.maxCities)) {
/* 2323 */       this.cities[28].addRoute(50, 90.0D);
/* 2324 */       this.routeCounter += 1;
/* 2325 */       this.cities[50].addRoute(28, 90.0D);
/* 2326 */       this.routeCounter += 1;
/*      */     }
/* 2328 */     if ((29 < this.maxCities) && (5 < this.maxCities)) {
/* 2329 */       this.cities[29].addRoute(5, 445.5D);
/* 2330 */       this.routeCounter += 1;
/* 2331 */       this.cities[5].addRoute(29, 445.5D);
/* 2332 */       this.routeCounter += 1;
/*      */     }
/* 2334 */     if ((30 < this.maxCities) && (31 < this.maxCities)) {
/* 2335 */       this.cities[30].addRoute(31, 544.5D);
/* 2336 */       this.routeCounter += 1;
/* 2337 */       this.cities[31].addRoute(30, 544.5D);
/* 2338 */       this.routeCounter += 1;
/*      */     }
/* 2340 */     if ((30 < this.maxCities) && (41 < this.maxCities)) {
/* 2341 */       this.cities[30].addRoute(41, 574.20000000000005D);
/* 2342 */       this.routeCounter += 1;
/* 2343 */       this.cities[41].addRoute(30, 574.20000000000005D);
/* 2344 */       this.routeCounter += 1;
/*      */     }
/* 2346 */     if ((30 < this.maxCities) && (43 < this.maxCities)) {
/* 2347 */       this.cities[30].addRoute(43, 980.0D);
/* 2348 */       this.routeCounter += 1;
/* 2349 */       this.cities[43].addRoute(30, 980.0D);
/* 2350 */       this.routeCounter += 1;
/*      */     }
/* 2352 */     if ((31 < this.maxCities) && (35 < this.maxCities)) {
/* 2353 */       this.cities[31].addRoute(35, 800.0D);
/* 2354 */       this.routeCounter += 1;
/* 2355 */       this.cities[35].addRoute(31, 800.0D);
/* 2356 */       this.routeCounter += 1;
/*      */     }
/* 2358 */     if ((31 < this.maxCities) && (38 < this.maxCities)) {
/* 2359 */       this.cities[31].addRoute(38, 450.0D);
/* 2360 */       this.routeCounter += 1;
/* 2361 */       this.cities[38].addRoute(31, 450.0D);
/* 2362 */       this.routeCounter += 1;
/*      */     }
/* 2364 */     if ((31 < this.maxCities) && (42 < this.maxCities)) {
/* 2365 */       this.cities[31].addRoute(42, 1000.0D);
/* 2366 */       this.routeCounter += 1;
/* 2367 */       this.cities[42].addRoute(31, 1000.0D);
/* 2368 */       this.routeCounter += 1;
/*      */     }
/* 2370 */     if ((32 < this.maxCities) && (34 < this.maxCities)) {
/* 2371 */       this.cities[32].addRoute(34, 600.0D);
/* 2372 */       this.routeCounter += 1;
/* 2373 */       this.cities[34].addRoute(32, 600.0D);
/* 2374 */       this.routeCounter += 1;
/*      */     }
/* 2376 */     if ((32 < this.maxCities) && (35 < this.maxCities)) {
/* 2377 */       this.cities[32].addRoute(35, 643.5D);
/* 2378 */       this.routeCounter += 1;
/* 2379 */       this.cities[35].addRoute(32, 643.5D);
/* 2380 */       this.routeCounter += 1;
/*      */     }
/* 2382 */     if ((32 < this.maxCities) && (38 < this.maxCities)) {
/* 2383 */       this.cities[32].addRoute(38, 700.0D);
/* 2384 */       this.routeCounter += 1;
/* 2385 */       this.cities[38].addRoute(32, 700.0D);
/* 2386 */       this.routeCounter += 1;
/*      */     }
/* 2388 */     if ((32 < this.maxCities) && (40 < this.maxCities)) {
/* 2389 */       this.cities[32].addRoute(40, 1120.0D);
/* 2390 */       this.routeCounter += 1;
/* 2391 */       this.cities[40].addRoute(32, 1120.0D);
/* 2392 */       this.routeCounter += 1;
/*      */     }
/* 2394 */     if ((32 < this.maxCities) && (45 < this.maxCities)) {
/* 2395 */       this.cities[32].addRoute(45, 1150.0D);
/* 2396 */       this.routeCounter += 1;
/* 2397 */       this.cities[45].addRoute(32, 1150.0D);
/* 2398 */       this.routeCounter += 1;
/*      */     }
/* 2400 */     if ((32 < this.maxCities) && (47 < this.maxCities)) {
/* 2401 */       this.cities[32].addRoute(47, 445.5D);
/* 2402 */       this.routeCounter += 1;
/* 2403 */       this.cities[47].addRoute(32, 445.5D);
/* 2404 */       this.routeCounter += 1;
/*      */     }
/* 2406 */     if ((32 < this.maxCities) && (48 < this.maxCities)) {
/* 2407 */       this.cities[32].addRoute(48, 950.0D);
/* 2408 */       this.routeCounter += 1;
/* 2409 */       this.cities[48].addRoute(32, 950.0D);
/* 2410 */       this.routeCounter += 1;
/*      */     }
/* 2412 */     if ((32 < this.maxCities) && (49 < this.maxCities)) {
/* 2413 */       this.cities[32].addRoute(49, 850.0D);
/* 2414 */       this.routeCounter += 1;
/* 2415 */       this.cities[49].addRoute(32, 850.0D);
/* 2416 */       this.routeCounter += 1;
/*      */     }
/* 2418 */     if ((32 < this.maxCities) && (50 < this.maxCities)) {
/* 2419 */       this.cities[32].addRoute(50, 450.0D);
/* 2420 */       this.routeCounter += 1;
/* 2421 */       this.cities[50].addRoute(32, 450.0D);
/* 2422 */       this.routeCounter += 1;
/*      */     }
/* 2424 */     if ((33 < this.maxCities) && (35 < this.maxCities)) {
/* 2425 */       this.cities[33].addRoute(35, 99.0D);
/* 2426 */       this.routeCounter += 1;
/* 2427 */       this.cities[35].addRoute(33, 99.0D);
/* 2428 */       this.routeCounter += 1;
/*      */     }
/* 2430 */     if ((34 < this.maxCities) && (35 < this.maxCities)) {
/* 2431 */       this.cities[34].addRoute(35, 247.5D);
/* 2432 */       this.routeCounter += 1;
/* 2433 */       this.cities[35].addRoute(34, 247.5D);
/* 2434 */       this.routeCounter += 1;
/*      */     }
/* 2436 */     if ((34 < this.maxCities) && (38 < this.maxCities)) {
/* 2437 */       this.cities[34].addRoute(38, 445.5D);
/* 2438 */       this.routeCounter += 1;
/* 2439 */       this.cities[38].addRoute(34, 445.5D);
/* 2440 */       this.routeCounter += 1;
/*      */     }
/* 2442 */     if ((34 < this.maxCities) && (45 < this.maxCities)) {
/* 2443 */       this.cities[34].addRoute(45, 891.0D);
/* 2444 */       this.routeCounter += 1;
/* 2445 */       this.cities[45].addRoute(34, 891.0D);
/* 2446 */       this.routeCounter += 1;
/*      */     }
/* 2448 */     if ((34 < this.maxCities) && (49 < this.maxCities)) {
/* 2449 */       this.cities[34].addRoute(49, 316.80000000000001D);
/* 2450 */       this.routeCounter += 1;
/* 2451 */       this.cities[49].addRoute(34, 316.80000000000001D);
/* 2452 */       this.routeCounter += 1;
/*      */     }
/* 2454 */     if ((34 < this.maxCities) && (50 < this.maxCities)) {
/* 2455 */       this.cities[34].addRoute(50, 310.0D);
/* 2456 */       this.routeCounter += 1;
/* 2457 */       this.cities[50].addRoute(34, 310.0D);
/* 2458 */       this.routeCounter += 1;
/*      */     }
/* 2460 */     if ((35 < this.maxCities) && (37 < this.maxCities)) {
/* 2461 */       this.cities[35].addRoute(37, 650.0D);
/* 2462 */       this.routeCounter += 1;
/* 2463 */       this.cities[37].addRoute(35, 650.0D);
/* 2464 */       this.routeCounter += 1;
/*      */     }
/* 2466 */     if ((35 < this.maxCities) && (40 < this.maxCities)) {
/* 2467 */       this.cities[35].addRoute(40, 1250.0D);
/* 2468 */       this.routeCounter += 1;
/* 2469 */       this.cities[40].addRoute(35, 1250.0D);
/* 2470 */       this.routeCounter += 1;
/*      */     }
/* 2472 */     if ((35 < this.maxCities) && (41 < this.maxCities)) {
/* 2473 */       this.cities[35].addRoute(41, 1150.0D);
/* 2474 */       this.routeCounter += 1;
/* 2475 */       this.cities[41].addRoute(35, 1150.0D);
/* 2476 */       this.routeCounter += 1;
/*      */     }
/* 2478 */     if ((35 < this.maxCities) && (42 < this.maxCities)) {
/* 2479 */       this.cities[35].addRoute(42, 1000.0D);
/* 2480 */       this.routeCounter += 1;
/* 2481 */       this.cities[42].addRoute(35, 1000.0D);
/* 2482 */       this.routeCounter += 1;
/*      */     }
/* 2484 */     if ((35 < this.maxCities) && (44 < this.maxCities)) {
/* 2485 */       this.cities[35].addRoute(44, 300.0D);
/* 2486 */       this.routeCounter += 1;
/* 2487 */       this.cities[44].addRoute(35, 300.0D);
/* 2488 */       this.routeCounter += 1;
/*      */     }
/* 2490 */     if ((35 < this.maxCities) && (45 < this.maxCities)) {
/* 2491 */       this.cities[35].addRoute(45, 1300.0D);
/* 2492 */       this.routeCounter += 1;
/* 2493 */       this.cities[45].addRoute(35, 1300.0D);
/* 2494 */       this.routeCounter += 1;
/*      */     }
/* 2496 */     if ((35 < this.maxCities) && (48 < this.maxCities)) {
/* 2497 */       this.cities[35].addRoute(48, 200.0D);
/* 2498 */       this.routeCounter += 1;
/* 2499 */       this.cities[48].addRoute(35, 200.0D);
/* 2500 */       this.routeCounter += 1;
/*      */     }
/* 2502 */     if ((35 < this.maxCities) && (49 < this.maxCities)) {
/* 2503 */       this.cities[35].addRoute(49, 180.0D);
/* 2504 */       this.routeCounter += 1;
/* 2505 */       this.cities[49].addRoute(35, 180.0D);
/* 2506 */       this.routeCounter += 1;
/*      */     }
/* 2508 */     if ((35 < this.maxCities) && (50 < this.maxCities)) {
/* 2509 */       this.cities[35].addRoute(50, 140.0D);
/* 2510 */       this.routeCounter += 1;
/* 2511 */       this.cities[50].addRoute(35, 140.0D);
/* 2512 */       this.routeCounter += 1;
/*      */     }
/* 2514 */     if ((36 < this.maxCities) && (42 < this.maxCities)) {
/* 2515 */       this.cities[36].addRoute(42, 550.0D);
/* 2516 */       this.routeCounter += 1;
/* 2517 */       this.cities[42].addRoute(36, 550.0D);
/* 2518 */       this.routeCounter += 1;
/*      */     }
/* 2520 */     if ((36 < this.maxCities) && (43 < this.maxCities)) {
/* 2521 */       this.cities[36].addRoute(43, 550.0D);
/* 2522 */       this.routeCounter += 1;
/* 2523 */       this.cities[43].addRoute(36, 550.0D);
/* 2524 */       this.routeCounter += 1;
/*      */     }
/* 2526 */     if ((37 < this.maxCities) && (47 < this.maxCities)) {
/* 2527 */       this.cities[37].addRoute(47, 495.0D);
/* 2528 */       this.routeCounter += 1;
/* 2529 */       this.cities[47].addRoute(37, 495.0D);
/* 2530 */       this.routeCounter += 1;
/*      */     }
/* 2532 */     if ((38 < this.maxCities) && (39 < this.maxCities)) {
/* 2533 */       this.cities[38].addRoute(39, 980.10000000000002D);
/* 2534 */       this.routeCounter += 1;
/* 2535 */       this.cities[39].addRoute(38, 980.10000000000002D);
/* 2536 */       this.routeCounter += 1;
/*      */     }
/* 2538 */     if ((38 < this.maxCities) && (42 < this.maxCities)) {
/* 2539 */       this.cities[38].addRoute(42, 1079.0999999999999D);
/* 2540 */       this.routeCounter += 1;
/* 2541 */       this.cities[42].addRoute(38, 1079.0999999999999D);
/* 2542 */       this.routeCounter += 1;
/*      */     }
/* 2544 */     if ((38 < this.maxCities) && (45 < this.maxCities)) {
/* 2545 */       this.cities[38].addRoute(45, 1200.0D);
/* 2546 */       this.routeCounter += 1;
/* 2547 */       this.cities[45].addRoute(38, 1200.0D);
/* 2548 */       this.routeCounter += 1;
/*      */     }
/* 2550 */     if ((38 < this.maxCities) && (48 < this.maxCities)) {
/* 2551 */       this.cities[38].addRoute(48, 148.5D);
/* 2552 */       this.routeCounter += 1;
/* 2553 */       this.cities[48].addRoute(38, 148.5D);
/* 2554 */       this.routeCounter += 1;
/*      */     }
/* 2556 */     if ((38 < this.maxCities) && (49 < this.maxCities)) {
/* 2557 */       this.cities[38].addRoute(49, 247.5D);
/* 2558 */       this.routeCounter += 1;
/* 2559 */       this.cities[49].addRoute(38, 247.5D);
/* 2560 */       this.routeCounter += 1;
/*      */     }
/* 2562 */     if ((38 < this.maxCities) && (50 < this.maxCities)) {
/* 2563 */       this.cities[38].addRoute(50, 250.0D);
/* 2564 */       this.routeCounter += 1;
/* 2565 */       this.cities[50].addRoute(38, 250.0D);
/* 2566 */       this.routeCounter += 1;
/*      */     }
/* 2568 */     if ((40 < this.maxCities) && (41 < this.maxCities)) {
/* 2569 */       this.cities[40].addRoute(41, 400.0D);
/* 2570 */       this.routeCounter += 1;
/* 2571 */       this.cities[41].addRoute(40, 400.0D);
/* 2572 */       this.routeCounter += 1;
/*      */     }
/* 2574 */     if ((40 < this.maxCities) && (42 < this.maxCities)) {
/* 2575 */       this.cities[40].addRoute(42, 500.0D);
/* 2576 */       this.routeCounter += 1;
/* 2577 */       this.cities[42].addRoute(40, 500.0D);
/* 2578 */       this.routeCounter += 1;
/*      */     }
/* 2580 */     if ((40 < this.maxCities) && (43 < this.maxCities)) {
/* 2581 */       this.cities[40].addRoute(43, 980.0D);
/* 2582 */       this.routeCounter += 1;
/* 2583 */       this.cities[43].addRoute(40, 980.0D);
/* 2584 */       this.routeCounter += 1;
/*      */     }
/* 2586 */     if ((40 < this.maxCities) && (46 < this.maxCities)) {
/* 2587 */       this.cities[40].addRoute(46, 500.0D);
/* 2588 */       this.routeCounter += 1;
/* 2589 */       this.cities[46].addRoute(40, 500.0D);
/* 2590 */       this.routeCounter += 1;
/*      */     }
/* 2592 */     if ((40 < this.maxCities) && (47 < this.maxCities)) {
/* 2593 */       this.cities[40].addRoute(47, 594.0D);
/* 2594 */       this.routeCounter += 1;
/* 2595 */       this.cities[47].addRoute(40, 594.0D);
/* 2596 */       this.routeCounter += 1;
/*      */     }
/* 2598 */     if ((41 < this.maxCities) && (42 < this.maxCities)) {
/* 2599 */       this.cities[41].addRoute(42, 250.0D);
/* 2600 */       this.routeCounter += 1;
/* 2601 */       this.cities[42].addRoute(41, 250.0D);
/* 2602 */       this.routeCounter += 1;
/*      */     }
/* 2604 */     if ((41 < this.maxCities) && (43 < this.maxCities)) {
/* 2605 */       this.cities[41].addRoute(43, 850.0D);
/* 2606 */       this.routeCounter += 1;
/* 2607 */       this.cities[43].addRoute(41, 850.0D);
/* 2608 */       this.routeCounter += 1;
/*      */     }
/* 2610 */     if ((41 < this.maxCities) && (50 < this.maxCities)) {
/* 2611 */       this.cities[41].addRoute(50, 1050.0D);
/* 2612 */       this.routeCounter += 1;
/* 2613 */       this.cities[50].addRoute(41, 1050.0D);
/* 2614 */       this.routeCounter += 1;
/*      */     }
/* 2616 */     if ((42 < this.maxCities) && (43 < this.maxCities)) {
/* 2617 */       this.cities[42].addRoute(43, 800.0D);
/* 2618 */       this.routeCounter += 1;
/* 2619 */       this.cities[43].addRoute(42, 800.0D);
/* 2620 */       this.routeCounter += 1;
/*      */     }
/* 2622 */     if ((42 < this.maxCities) && (45 < this.maxCities)) {
/* 2623 */       this.cities[42].addRoute(45, 500.0D);
/* 2624 */       this.routeCounter += 1;
/* 2625 */       this.cities[45].addRoute(42, 500.0D);
/* 2626 */       this.routeCounter += 1;
/*      */     }
/* 2628 */     if ((42 < this.maxCities) && (46 < this.maxCities)) {
/* 2629 */       this.cities[42].addRoute(46, 400.0D);
/* 2630 */       this.routeCounter += 1;
/* 2631 */       this.cities[46].addRoute(42, 400.0D);
/* 2632 */       this.routeCounter += 1;
/*      */     }
/* 2634 */     if ((42 < this.maxCities) && (49 < this.maxCities)) {
/* 2635 */       this.cities[42].addRoute(49, 900.0D);
/* 2636 */       this.routeCounter += 1;
/* 2637 */       this.cities[49].addRoute(42, 900.0D);
/* 2638 */       this.routeCounter += 1;
/*      */     }
/* 2640 */     if ((42 < this.maxCities) && (50 < this.maxCities)) {
/* 2641 */       this.cities[42].addRoute(50, 950.0D);
/* 2642 */       this.routeCounter += 1;
/* 2643 */       this.cities[50].addRoute(42, 950.0D);
/* 2644 */       this.routeCounter += 1;
/*      */     }
/* 2646 */     if ((43 < this.maxCities) && (45 < this.maxCities)) {
/* 2647 */       this.cities[43].addRoute(45, 891.0D);
/* 2648 */       this.routeCounter += 1;
/* 2649 */       this.cities[45].addRoute(43, 891.0D);
/* 2650 */       this.routeCounter += 1;
/*      */     }
/* 2652 */     if ((44 < this.maxCities) && (50 < this.maxCities)) {
/* 2653 */       this.cities[44].addRoute(50, 300.0D);
/* 2654 */       this.routeCounter += 1;
/* 2655 */       this.cities[50].addRoute(44, 300.0D);
/* 2656 */       this.routeCounter += 1;
/*      */     }
/* 2658 */     if ((45 < this.maxCities) && (46 < this.maxCities)) {
/* 2659 */       this.cities[45].addRoute(46, 445.5D);
/* 2660 */       this.routeCounter += 1;
/* 2661 */       this.cities[46].addRoute(45, 445.5D);
/* 2662 */       this.routeCounter += 1;
/*      */     }
/* 2664 */     if ((45 < this.maxCities) && (47 < this.maxCities)) {
/* 2665 */       this.cities[45].addRoute(47, 841.5D);
/* 2666 */       this.routeCounter += 1;
/* 2667 */       this.cities[47].addRoute(45, 841.5D);
/* 2668 */       this.routeCounter += 1;
/*      */     }
/* 2670 */     if ((45 < this.maxCities) && (50 < this.maxCities)) {
/* 2671 */       this.cities[45].addRoute(50, 1200.0D);
/* 2672 */       this.routeCounter += 1;
/* 2673 */       this.cities[50].addRoute(45, 1200.0D);
/* 2674 */       this.routeCounter += 1;
/*      */     }
/* 2676 */     if ((48 < this.maxCities) && (49 < this.maxCities)) {
/* 2677 */       this.cities[48].addRoute(49, 100.0D);
/* 2678 */       this.routeCounter += 1;
/* 2679 */       this.cities[49].addRoute(48, 100.0D);
/* 2680 */       this.routeCounter += 1;
/*      */     }
/* 2682 */     if ((49 < this.maxCities) && (50 < this.maxCities)) {
/* 2683 */       this.cities[49].addRoute(50, 100.0D);
/* 2684 */       this.routeCounter += 1;
/* 2685 */       this.cities[50].addRoute(49, 100.0D);
/* 2686 */       this.routeCounter += 1;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /mnt/129A6EF79A6ED6AF/[data]/study/[current]/cs220/assignment4/sample executable/
 * Qualified Name:     TraversalProgram
 * JD-Core Version:    0.6.2
 */