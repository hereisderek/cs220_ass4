/*
 * TraversalApplication.java
 *
 * This is the Java application for the COMPSCI220
 * assignment on tree traversal.
 *
 *
 * Author: Ulrich Speidel
 * Version: 1
 * Date: 21/9/2011
 *
 */

public class TraversalApplication {
    public static void main(String[] args) {
        TraversalProgram p = new TraversalProgram();
        p.start();
    }
}